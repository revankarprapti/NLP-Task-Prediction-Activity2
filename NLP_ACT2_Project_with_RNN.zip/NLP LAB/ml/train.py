"""
Automatic Task Prediction Using NLP and Machine Learning
==========================================================
Training pipeline.

This script faithfully reproduces the methodology of the original academic
notebook (``ml/reference_notebook.ipynb``):

    1. Load the raw Customer Support Ticket dataset
    2. Data quality analysis (missing values, duplicates)
    3. NLP text cleaning (``clean_text``)
    4. Stratified train / test split (80 / 20, random_state=42)
    5. TF-IDF feature extraction fitted ONLY on the training split
       (no data leakage)
    6. Train Logistic Regression and Linear SVM
    7. Evaluate on the unseen test split
    8. Persist the fitted vectorizer + both models + all metrics as artifacts

Run with::

    python ml/train.py

The backend loads the artifacts produced here.  Metrics are reported exactly
as measured on the held-out test set - they are intentionally *not* inflated.
"""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone

import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)
from sklearn.model_selection import train_test_split
from sklearn.svm import LinearSVC

# Allow ``python ml/train.py`` and ``python -m ml.train`` to both work.
if __package__ in (None, ""):
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ml.preprocessing import clean_text
else:
    from .preprocessing import clean_text

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
ML_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(ML_DIR)
DATA_DIR = os.path.join(PROJECT_ROOT, "data")
ARTIFACTS_DIR = os.path.join(ML_DIR, "artifacts")
OUTPUTS_DIR = os.path.join(DATA_DIR, "outputs")

DATA_FILE = os.path.join(DATA_DIR, "Customer Support Ticket Dataset.csv")
CLEANED_FILE = os.path.join(OUTPUTS_DIR, "cleaned_customer_support_tickets.csv")
PREDICTIONS_FILE = os.path.join(OUTPUTS_DIR, "act1_prediction_results.csv")

TARGET_COLUMN = "Ticket Type"
TEXT_COLUMN = "Ticket Description"
RANDOM_STATE = 42
TEST_SIZE = 0.20


def _weighted_metrics(y_true, y_pred) -> dict:
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(
            precision_score(y_true, y_pred, average="weighted", zero_division=0)
        ),
        "recall": float(
            recall_score(y_true, y_pred, average="weighted", zero_division=0)
        ),
        "f1": float(f1_score(y_true, y_pred, average="weighted", zero_division=0)),
    }


def _per_class_report(y_true, y_pred, labels) -> dict:
    report = classification_report(
        y_true, y_pred, labels=labels, output_dict=True, zero_division=0
    )
    per_class = {}
    for label in labels:
        stats = report.get(label, {})
        per_class[label] = {
            "precision": float(stats.get("precision", 0.0)),
            "recall": float(stats.get("recall", 0.0)),
            "f1": float(stats.get("f1-score", 0.0)),
            "support": int(stats.get("support", 0)),
        }
    return per_class


def _confusion(y_true, y_pred, labels) -> dict:
    matrix = confusion_matrix(y_true, y_pred, labels=labels)
    return {
        "labels": list(labels),
        "matrix": matrix.astype(int).tolist(),
    }


def _missing_table(df: pd.DataFrame) -> list:
    missing = df.isnull().sum()
    total = len(df)
    rows = []
    for column in df.columns:
        count = int(missing[column])
        rows.append(
            {
                "column": column,
                "missing": count,
                "percentage": round(count / total * 100, 2) if total else 0.0,
            }
        )
    return rows


def train() -> dict:
    """Run the full pipeline and persist artifacts. Returns the metrics dict."""
    os.makedirs(ARTIFACTS_DIR, exist_ok=True)
    os.makedirs(OUTPUTS_DIR, exist_ok=True)

    if not os.path.exists(DATA_FILE):
        raise FileNotFoundError(
            f"Dataset not found at {DATA_FILE}. "
            "Place 'Customer Support Ticket Dataset.csv' in the data/ directory."
        )

    # ---- 1. Load ---------------------------------------------------------
    df = pd.read_csv(DATA_FILE)
    df.columns = df.columns.str.strip()
    raw_rows = len(df)
    raw_columns = list(df.columns)
    missing_before = _missing_table(df)
    duplicate_rows = int(df.duplicated().sum())

    # ---- 2. Remove duplicates / missing text or target -------------------
    if duplicate_rows > 0:
        df = df.drop_duplicates()
    df = df.dropna(subset=[TEXT_COLUMN, TARGET_COLUMN]).copy()

    # ---- 3. Preprocess ---------------------------------------------------
    df["Clean_Text"] = df[TEXT_COLUMN].apply(clean_text)
    df = df[df["Clean_Text"].str.strip() != ""].copy()

    cleaned_rows = len(df)

    unique_cleaned = int(df["Clean_Text"].nunique())
    duplicate_cleaned = int(cleaned_rows - unique_cleaned)

    # ---- 4. Persist cleaned dataset -------------------------------------
    df.to_csv(CLEANED_FILE, index=False)

    # ---- 5. Features / target -------------------------------------------
    X = df["Clean_Text"]
    y = df[TARGET_COLUMN]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=y
    )

    # ---- 6. TF-IDF fitted on TRAIN ONLY (no leakage) ---------------------
    tfidf = TfidfVectorizer(
        stop_words="english",
        max_features=5000,
        ngram_range=(1, 2),
        min_df=2,
    )
    X_train_tfidf = tfidf.fit_transform(X_train)
    X_test_tfidf = tfidf.transform(X_test)

    # ---- 7. Train models -------------------------------------------------
    logistic_model = LogisticRegression(max_iter=1000, random_state=RANDOM_STATE)
    logistic_model.fit(X_train_tfidf, y_train)

    svm_model = LinearSVC(random_state=RANDOM_STATE)
    svm_model.fit(X_train_tfidf, y_train)

    y_pred_lr = logistic_model.predict(X_test_tfidf)
    y_pred_svm = svm_model.predict(X_test_tfidf)

    # ---- 8. Evaluate -----------------------------------------------------
    labels = sorted(y.unique().tolist())

    lr_metrics = _weighted_metrics(y_test, y_pred_lr)
    svm_metrics = _weighted_metrics(y_test, y_pred_svm)

    best_model = "Logistic Regression" if lr_metrics["f1"] >= svm_metrics["f1"] else "Linear SVM"

    models_metrics = {
        "Logistic Regression": {
            **lr_metrics,
            "per_class": _per_class_report(y_test, y_pred_lr, labels),
            "confusion": _confusion(y_test, y_pred_lr, labels),
        },
        "Linear SVM": {
            **svm_metrics,
            "per_class": _per_class_report(y_test, y_pred_svm, labels),
            "confusion": _confusion(y_test, y_pred_svm, labels),
        },
    }

    # ---- 9. Save predictions CSV ----------------------------------------
    best_predictions = y_pred_lr if best_model == "Logistic Regression" else y_pred_svm
    pd.DataFrame(
        {
            "Actual Ticket Type": y_test.values,
            "Predicted Ticket Type": best_predictions,
            "Ticket Description": X_test.values,
        }
    ).to_csv(PREDICTIONS_FILE, index=False)

    # ---- 10. Persist artifacts ------------------------------------------
    joblib.dump(tfidf, os.path.join(ARTIFACTS_DIR, "tfidf_vectorizer.joblib"))
    joblib.dump(
        logistic_model, os.path.join(ARTIFACTS_DIR, "logistic_regression.joblib")
    )
    joblib.dump(svm_model, os.path.join(ARTIFACTS_DIR, "linear_svm.joblib"))

    class_counts = df[TARGET_COLUMN].value_counts()
    class_distribution = [
        {"category": str(name), "count": int(count)}
        for name, count in class_counts.items()
    ]

    metadata = {
        "project": "Automatic Task Prediction Using NLP and Machine Learning",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "dataset": {
            "file": os.path.basename(DATA_FILE),
            "raw_rows": raw_rows,
            "raw_columns": len(raw_columns),
            "cleaned_rows": cleaned_rows,
            "removed_rows": raw_rows - cleaned_rows,
            "duplicate_rows": duplicate_rows,
            "unique_cleaned_texts": unique_cleaned,
            "duplicate_cleaned_texts": duplicate_cleaned,
            "categories": labels,
            "n_categories": len(labels),
            "class_distribution": class_distribution,
            "missing_values": missing_before,
        },
        "preprocessing": {
            "clean_text_rules": [
                "lowercase",
                "expand {product_purchased} -> product",
                "remove emails",
                "remove URLs",
                "remove numbers",
                "keep only letters and spaces",
                "collapse whitespace",
            ],
        },
        "features": {
            "vectorizer": "TfidfVectorizer",
            "stop_words": "english",
            "max_features": 5000,
            "ngram_range": [1, 2],
            "min_df": 2,
            "vocabulary_size": int(len(tfidf.vocabulary_)),
            "fit_on": "training split only (no data leakage)",
        },
        "split": {
            "test_size": TEST_SIZE,
            "random_state": RANDOM_STATE,
            "stratified": True,
            "train_rows": int(len(X_train)),
            "test_rows": int(len(X_test)),
        },
        "models": models_metrics,
        "best_model": best_model,
    }

    with open(
        os.path.join(ARTIFACTS_DIR, "metadata.json"), "w", encoding="utf-8"
    ) as handle:
        json.dump(metadata, handle, indent=2)

    joblib.dump(labels, os.path.join(ARTIFACTS_DIR, "classes.joblib"))

    return metadata


def main() -> None:
    metadata = train()
    print("=" * 70)
    print("AUTOMATIC TASK PREDICTION - TRAINING COMPLETE")
    print("=" * 70)
    print(f"Dataset rows (raw)     : {metadata['dataset']['raw_rows']}")
    print(f"Dataset rows (cleaned) : {metadata['dataset']['cleaned_rows']}")
    print(f"Categories             : {metadata['dataset']['n_categories']}")
    print(f"Train / Test           : {metadata['split']['train_rows']} / {metadata['split']['test_rows']}")
    print("-" * 70)
    for name, metrics in metadata["models"].items():
        print(
            f"{name:22s} acc={metrics['accuracy']:.4f} "
            f"prec={metrics['precision']:.4f} "
            f"rec={metrics['recall']:.4f} f1={metrics['f1']:.4f}"
        )
    print("-" * 70)
    print(f"Best model (by F1)     : {metadata['best_model']}")
    print(f"Artifacts directory    : {ARTIFACTS_DIR}")
    print("=" * 70)


if __name__ == "__main__":
    sys.exit(main())
