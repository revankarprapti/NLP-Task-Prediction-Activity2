"""Shared NLP preprocessing for training and inference."""

from __future__ import annotations

import re


def clean_text(text: object) -> str:
    """Clean a single ticket description.

    Mirrors the preprocessing used by the original notebook exactly:
    lowercase, expand the ``{product_purchased}`` placeholder, strip emails,
    URLs, numbers and all non-letter characters, then collapse whitespace.
    """
    text = str(text)
    text = text.lower()
    text = text.replace("{product_purchased}", "product")
    text = re.sub(r"\S+@\S+", " ", text)           # emails
    text = re.sub(r"http\S+|www\S+", " ", text)    # URLs
    text = re.sub(r"\d+", " ", text)               # numbers
    text = re.sub(r"[^a-zA-Z\s]", " ", text)       # punctuation / specials
    text = re.sub(r"\s+", " ", text).strip()       # collapse whitespace
    return text
