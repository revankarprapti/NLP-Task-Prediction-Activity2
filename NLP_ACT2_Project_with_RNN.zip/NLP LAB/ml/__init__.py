"""Machine learning pipeline package for Automatic Task Prediction."""
