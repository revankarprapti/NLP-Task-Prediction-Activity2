"""Small vanilla RNN network and tokenization helpers for ticket text classification."""
from __future__ import annotations
from collections import Counter
import re
import torch
from torch import nn
from torch.nn.utils.rnn import pack_padded_sequence

PAD_TOKEN = "<PAD>"
UNK_TOKEN = "<UNK>"


def build_vocab(texts, max_vocab=12000):
    counts = Counter(token for text in texts for token in str(text).split())
    vocab = {PAD_TOKEN: 0, UNK_TOKEN: 1}
    for token, _ in counts.most_common(max_vocab - len(vocab)):
        vocab[token] = len(vocab)
    return vocab


def encode_text(text, vocab, max_length=100):
    tokens = str(text).split()[:max_length]
    ids = [vocab.get(token, vocab[UNK_TOKEN]) for token in tokens]
    if not ids:
        ids = [vocab[UNK_TOKEN]]
    ids = ids[:max_length]
    return ids + [0] * (max_length - len(ids))


class TicketRNN(nn.Module):
    def __init__(self, vocab_size: int, num_classes: int, embedding_dim: int = 64, hidden_size: int = 64):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        self.rnn = nn.RNN(embedding_dim, hidden_size, batch_first=True, nonlinearity="tanh")
        self.dropout = nn.Dropout(0.25)
        self.classifier = nn.Linear(hidden_size, num_classes)

    def forward(self, token_ids):
        embedded = self.embedding(token_ids)
        lengths = (token_ids != 0).sum(dim=1).clamp(min=1).cpu()
        packed = pack_padded_sequence(embedded, lengths, batch_first=True, enforce_sorted=False)
        _, hidden = self.rnn(packed)
        return self.classifier(self.dropout(hidden[-1]))
