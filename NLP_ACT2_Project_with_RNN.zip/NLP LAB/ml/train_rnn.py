"""Train and evaluate a vanilla RNN model for customer support ticket types.

Run after the standard project setup with: python ml/train_rnn.py
The model uses a vocabulary learned only from the training split, padded token
sequences, an embedding layer, a vanilla RNN, and a multiclass output layer.
"""
from __future__ import annotations
import json, os, sys, random
from datetime import datetime, timezone
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report, confusion_matrix

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from ml.preprocessing import clean_text
from ml.rnn_model import TicketRNN, build_vocab, encode_text

DATA = os.path.join(ROOT, 'data', 'Customer Support Ticket Dataset.csv')
ART = os.path.join(ROOT, 'ml', 'artifacts')
SEED, MAX_LENGTH, BATCH_SIZE, EPOCHS = 42, 100, 64, 6

def main():
    random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
    torch.set_num_threads(max(1, min(4, os.cpu_count() or 1)))
    os.makedirs(ART, exist_ok=True)
    df = pd.read_csv(DATA); df.columns = df.columns.str.strip()
    df = df.drop_duplicates().dropna(subset=['Ticket Description', 'Ticket Type']).copy()
    df['Clean_Text'] = df['Ticket Description'].apply(clean_text)
    df = df[df['Clean_Text'].str.strip().ne('')]
    X_train, X_test, y_train, y_test = train_test_split(df['Clean_Text'], df['Ticket Type'], test_size=.2, random_state=SEED, stratify=df['Ticket Type'])
    labels = sorted(df['Ticket Type'].astype(str).unique().tolist())
    label_to_id = {label: i for i, label in enumerate(labels)}
    vocab = build_vocab(X_train)
    train_x = torch.tensor([encode_text(t, vocab, MAX_LENGTH) for t in X_train], dtype=torch.long)
    test_x = torch.tensor([encode_text(t, vocab, MAX_LENGTH) for t in X_test], dtype=torch.long)
    train_y = torch.tensor([label_to_id[str(y)] for y in y_train], dtype=torch.long)
    test_y = torch.tensor([label_to_id[str(y)] for y in y_test], dtype=torch.long)
    loader = DataLoader(TensorDataset(train_x, train_y), batch_size=BATCH_SIZE, shuffle=True)
    model = TicketRNN(len(vocab), len(labels))
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    criterion = nn.CrossEntropyLoss()
    model.train()
    for epoch in range(EPOCHS):
        total_loss = 0.0
        for bx, by in loader:
            optimizer.zero_grad(); logits = model(bx); loss = criterion(logits, by)
            loss.backward(); nn.utils.clip_grad_norm_(model.parameters(), 1.0); optimizer.step()
            total_loss += loss.item() * len(by)
        print(f'Epoch {epoch+1}/{EPOCHS} - loss: {total_loss / len(train_y):.4f}')
    model.eval()
    with torch.no_grad():
        predictions = model(test_x).argmax(dim=1).numpy()
    y_true = test_y.numpy()
    report = classification_report(y_true, predictions, labels=list(range(len(labels))), output_dict=True, zero_division=0)
    per_class = {label: {'precision': float(report[str(i)]['precision']), 'recall': float(report[str(i)]['recall']), 'f1': float(report[str(i)]['f1-score']), 'support': int(report[str(i)]['support'])} for i, label in enumerate(labels)}
    metrics = {
        'accuracy': float(accuracy_score(y_true, predictions)),
        'precision': float(precision_score(y_true, predictions, average='weighted', zero_division=0)),
        'recall': float(recall_score(y_true, predictions, average='weighted', zero_division=0)),
        'f1': float(f1_score(y_true, predictions, average='weighted', zero_division=0)),
        'per_class': per_class,
        'confusion': {'labels': labels, 'matrix': confusion_matrix(y_true, predictions, labels=list(range(len(labels)))).astype(int).tolist()},
        'epochs': EPOCHS,
        'max_length': MAX_LENGTH,
        'vocabulary_size': len(vocab),
        'generated_at': datetime.now(timezone.utc).isoformat(),
    }
    torch.save({'state_dict': model.state_dict(), 'vocab_size': len(vocab), 'num_classes': len(labels), 'embedding_dim': 64, 'hidden_size': 64}, os.path.join(ART, 'rnn_model.pt'))
    with open(os.path.join(ART, 'rnn_vocab.json'), 'w', encoding='utf-8') as f: json.dump(vocab, f)
    with open(os.path.join(ART, 'rnn_classes.json'), 'w', encoding='utf-8') as f: json.dump(labels, f)
    with open(os.path.join(ART, 'rnn_metrics.json'), 'w', encoding='utf-8') as f: json.dump(metrics, f, indent=2)
    print('\nRNN evaluation (held-out test set)')
    for k in ('accuracy','precision','recall','f1'): print(f'{k}: {metrics[k]:.4f}')
    print(f'Artifacts saved to {ART}')

if __name__ == '__main__': main()
