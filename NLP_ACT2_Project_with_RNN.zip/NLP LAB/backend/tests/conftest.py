"""Pytest configuration for backend tests."""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parent.parent
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

# Use a throwaway history file so tests never touch real predictions.
os.environ.setdefault(
    "HISTORY_FILE",
    str(Path(tempfile.gettempdir()) / "atp_test_history.csv"),
)
