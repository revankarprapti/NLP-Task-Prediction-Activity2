"""End-to-end API tests exercising real ML inference and dataset access."""

from __future__ import annotations

import io

import pytest
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as test_client:
        yield test_client


def test_health(client):
    response = client.get("/api/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert body["ml_ready"] is True


def test_dashboard_stats(client):
    response = client.get("/api/dashboard/stats")
    assert response.status_code == 200
    body = response.json()
    cards = body["cards"]
    assert cards["total_tickets"] == 8469
    assert cards["total_categories"] == 5
    assert 0.0 <= cards["accuracy"] <= 1.0
    assert 0.0 <= cards["f1"] <= 1.0
    assert len(body["category_distribution"]) == 5
    assert len(body["model_comparison"]) == 3
    assert body["confusion_matrix"]["model"]


def test_dataset_pagination_and_filters(client):
    response = client.get("/api/dataset", params={"page": 1, "page_size": 5})
    assert response.status_code == 200
    body = response.json()
    assert len(body["rows"]) == 5
    assert body["total"] == 8469
    assert body["stats"]["total_rows"] == 8469
    assert body["filter_options"]["ticket_types"]

    filtered = client.get(
        "/api/dataset", params={"ticket_type": "Refund request", "page_size": 3}
    ).json()
    assert all(row["Ticket Type"] == "Refund request" for row in filtered["rows"])


def test_dataset_search(client):
    body = client.get(
        "/api/dataset", params={"search": "refund", "page_size": 5}
    ).json()
    assert body["total"] >= 0


def test_models_comparison(client):
    body = client.get("/api/models/comparison").json()
    assert len(body["models"]) == 3
    names = {model["name"] for model in body["models"]}
    assert names == {"Logistic Regression", "Linear SVM", "Recurrent Neural Network (RNN)"}
    assert body["best_model"] in names
    assert body["features"]["fit_on"].startswith("training split")


def test_predict_best_model(client):
    response = client.post("/api/predict", json={"text": "I want a refund for this product"})
    assert response.status_code == 200
    body = response.json()
    assert body["predicted_category"]
    assert body["model_key"] in ("logistic_regression", "linear_svm", "rnn")
    assert isinstance(body["scores"], list) and len(body["scores"]) == 5
    assert 0.0 <= body["confidence"] <= 1.0
    assert body["cleaned_text"]


def test_predict_explicit_svm(client):
    body = client.post(
        "/api/predict",
        json={"text": "The application keeps crashing", "model": "linear_svm"},
    ).json()
    assert body["model_key"] == "linear_svm"
    assert "softmax" in body["confidence_method"]


def test_predict_rejects_empty(client):
    response = client.post("/api/predict", json={"text": "!!!"})
    assert response.status_code == 422


def test_history_and_export(client):
    client.post("/api/predict", json={"text": "Please cancel my subscription"})
    history = client.get("/api/predictions/history").json()
    assert history["total"] >= 1
    assert history["items"][0]["predicted_category"]

    export = client.get("/api/predictions/export")
    assert export.status_code == 200
    assert "text/csv" in export.headers["content-type"]
    text = export.content.decode("utf-8")
    assert text.splitlines()[0] == (
        "id,timestamp,input_text,cleaned_text,predicted_category,model,"
        "confidence,confidence_supported"
    )


def test_predict_explicit_rnn(client):
    response = client.post("/api/predict", json={"text": "I need help with a refund", "model": "rnn"})
    assert response.status_code == 200
    body = response.json()
    assert body["model_key"] == "rnn"
    assert body["model"] == "Recurrent Neural Network (RNN)"
    assert len(body["scores"]) == 5
