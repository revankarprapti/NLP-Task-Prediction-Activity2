"""Application configuration resolved from environment variables."""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

# backend/app/config.py -> backend/app -> backend -> project root
APP_DIR = Path(__file__).resolve().parent
BACKEND_DIR = APP_DIR.parent
PROJECT_ROOT = BACKEND_DIR.parent

# Load .env from the backend directory and the project root (first found wins).
for candidate in (BACKEND_DIR / ".env", PROJECT_ROOT / ".env"):
    if candidate.exists():
        load_dotenv(candidate, override=False)


def _resolve(value: str | None, default: Path) -> Path:
    if not value:
        return default
    path = Path(value).expanduser()
    return path if path.is_absolute() else (PROJECT_ROOT / path)


DATA_DIR = _resolve(os.getenv("DATA_DIR"), PROJECT_ROOT / "data")
ARTIFACTS_DIR = _resolve(os.getenv("ARTIFACTS_DIR"), PROJECT_ROOT / "ml" / "artifacts")
FRONTEND_DIST = _resolve(
    os.getenv("FRONTEND_DIST"), PROJECT_ROOT / "frontend" / "dist"
)

DATASET_FILE = DATA_DIR / "Customer Support Ticket Dataset.csv"
HISTORY_FILE = _resolve(os.getenv("HISTORY_FILE"), DATA_DIR / "prediction_history.csv")

ALLOWED_ORIGINS = [
    origin.strip()
    for origin in os.getenv(
        "ALLOWED_ORIGINS",
        "http://localhost:5173,http://127.0.0.1:5173,http://localhost:4173",
    ).split(",")
    if origin.strip()
]

MAX_TEXT_LENGTH = int(os.getenv("MAX_TEXT_LENGTH", "5000"))

API_HOST = os.getenv("API_HOST", "127.0.0.1")
API_PORT = int(os.getenv("API_PORT", "8000"))
