"""FastAPI application entrypoint."""

from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .config import ALLOWED_ORIGINS, API_HOST, API_PORT, FRONTEND_DIST, PROJECT_ROOT
from .routers import dashboard, dataset, models, predict, predictions
from .services.dataset_service import get_dataset_service
from .services.history_store import get_history_store
from .services.ml_service import ArtifactsNotFoundError, get_ml_service


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.ml_ready = False
    app.state.ml_error = None
    try:
        get_ml_service().load()
        get_dataset_service().load()
        get_history_store()
        app.state.ml_ready = True
    except (ArtifactsNotFoundError, FileNotFoundError) as error:
        app.state.ml_error = str(error)
        print("\n[WARNING] Model artifacts not ready:", error, "\n")
    yield


app = FastAPI(
    title="Automatic Task Prediction API",
    description=(
        "NLP + Machine Learning API for automatic customer support ticket "
        "classification. Trained on the Customer Support Ticket dataset using "
        "TF-IDF, Logistic Regression and Linear SVM."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS if ALLOWED_ORIGINS else ["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(predict.router)
app.include_router(dashboard.router)
app.include_router(dataset.router)
app.include_router(models.router)
app.include_router(predictions.router)


@app.exception_handler(ArtifactsNotFoundError)
async def artifacts_error_handler(_: Request, exc: ArtifactsNotFoundError) -> JSONResponse:
    return JSONResponse(
        status_code=503,
        content={"detail": str(exc)},
    )


@app.exception_handler(FileNotFoundError)
async def file_error_handler(_: Request, exc: FileNotFoundError) -> JSONResponse:
    return JSONResponse(status_code=503, content={"detail": str(exc)})


# --------------------------------------------------------------------------
# Production single-process deployment: serve the built React SPA from the
# FastAPI backend when `frontend/dist` exists. In development the Vite dev
# server (port 5173) talks to this API over CORS instead.
# --------------------------------------------------------------------------
def mount_frontend_spa() -> None:
    dist_dir: Path = FRONTEND_DIST
    assets_dir = dist_dir / "assets"

    if not dist_dir.is_dir():
        return

    if assets_dir.is_dir():
        app.mount("/assets", StaticFiles(directory=assets_dir), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    def spa_fallback(full_path: str) -> FileResponse:
        candidate = (dist_dir / full_path).resolve()
        if (
            full_path
            and candidate.is_file()
            and candidate.is_relative_to(dist_dir.resolve())
        ):
            return FileResponse(candidate)
        return FileResponse(dist_dir / "index.html")


@app.get("/", tags=["meta"], include_in_schema=False, response_model=None)
def root_redirect() -> FileResponse | dict:
    if FRONTEND_DIST.is_dir():
        return FileResponse(FRONTEND_DIST / "index.html")
    return {
        "name": "Automatic Task Prediction Using NLP and Machine Learning",
        "version": "1.0.0",
        "docs": "/docs",
        "endpoints": [
            "POST /api/predict",
            "GET /api/dashboard/stats",
            "GET /api/dataset",
            "GET /api/models/comparison",
            "GET /api/predictions/history",
        ],
    }


@app.get("/api/health", tags=["meta"])
def health() -> dict:
    from fastapi import Request  # noqa: F401

    return {
        "status": "ok",
        "project_root": str(PROJECT_ROOT),
        "ml_ready": bool(app.state.ml_ready),
        "ml_error": app.state.ml_error,
    }


# Registered last so it never shadows /api/* or /docs routes.
mount_frontend_spa()


if __name__ == "__main__":  # pragma: no cover
    import uvicorn

    uvicorn.run("app.main:app", host=API_HOST, port=API_PORT, reload=True)
