"""In-memory access to the real customer support ticket dataset."""

from __future__ import annotations

import threading
from typing import Any

import numpy as np
import pandas as pd

from ..config import DATASET_FILE

TEXT_COLUMN = "Ticket Description"
TARGET_COLUMN = "Ticket Type"
PRIORITY_COLUMN = "Ticket Priority"
STATUS_COLUMN = "Ticket Status"

SEARCH_COLUMNS = ["Ticket Description", "Ticket Subject", "Customer Name"]


def _sanitize(value: Any) -> Any:
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    return value


class DatasetService:
    _instance: "DatasetService | None" = None
    _lock = threading.Lock()

    def __init__(self) -> None:
        self.df: pd.DataFrame | None = None

    @classmethod
    def instance(cls) -> "DatasetService":
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    service = cls()
                    service.load()
                    cls._instance = service
        return cls._instance

    def load(self) -> None:
        if not DATASET_FILE.exists():
            raise FileNotFoundError(
                f"Dataset not found at {DATASET_FILE}. "
                "Place 'Customer Support Ticket Dataset.csv' in the data/ directory."
            )
        frame = pd.read_csv(DATASET_FILE)
        frame.columns = frame.columns.str.strip()
        self.df = frame

    @property
    def columns(self) -> list[str]:
        assert self.df is not None
        return list(self.df.columns)

    def filter_options(self) -> dict[str, list[str]]:
        assert self.df is not None
        return {
            "ticket_types": sorted(
                self.df[TARGET_COLUMN].dropna().unique().tolist()
            ),
            "priorities": sorted(
                self.df[PRIORITY_COLUMN].dropna().unique().tolist()
            ),
            "statuses": sorted(
                self.df[STATUS_COLUMN].dropna().unique().tolist()
            ),
        }

    def stats(self) -> dict[str, Any]:
        assert self.df is not None
        df = self.df
        missing = [
            {
                "column": column,
                "missing": int(df[column].isnull().sum()),
                "percentage": round(float(df[column].isnull().mean() * 100), 2),
            }
            for column in df.columns
        ]
        satisfaction = df["Customer Satisfaction Rating"].dropna()

        def counts(column: str) -> list[dict[str, Any]]:
            values = df[column].fillna("Unknown").value_counts()
            return [
                {"label": str(label), "count": int(count)}
                for label, count in values.items()
            ]

        return {
            "total_rows": int(len(df)),
            "total_columns": int(df.shape[1]),
            "total_categories": int(df[TARGET_COLUMN].nunique(dropna=True)),
            "duplicate_rows": int(df.duplicated().sum()),
            "ticket_type_distribution": counts(TARGET_COLUMN),
            "priority_distribution": counts(PRIORITY_COLUMN),
            "status_distribution": counts(STATUS_COLUMN),
            "channel_distribution": counts("Ticket Channel"),
            "missing_values": missing,
            "average_satisfaction": (
                round(float(satisfaction.mean()), 3)
                if not satisfaction.empty
                else None
            ),
            "columns": list(df.columns),
        }

    def query(
        self,
        *,
        search: str | None = None,
        ticket_type: str | None = None,
        priority: str | None = None,
        status: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> dict[str, Any]:
        assert self.df is not None
        frame = self.df

        if ticket_type:
            frame = frame[frame[TARGET_COLUMN] == ticket_type]
        if priority:
            frame = frame[frame[PRIORITY_COLUMN] == priority]
        if status:
            frame = frame[frame[STATUS_COLUMN] == status]
        if search:
            needle = search.strip().lower()
            mask = pd.Series(False, index=frame.index)
            for column in SEARCH_COLUMNS:
                mask = mask | frame[column].fillna("").str.lower().str.contains(
                    needle, regex=False
                )
            frame = frame[mask]

        total = int(len(frame))
        page = max(1, page)
        page_size = max(1, min(page_size, 200))
        total_pages = max(1, (total + page_size - 1) // page_size)
        page = min(page, total_pages)

        start = (page - 1) * page_size
        window = frame.iloc[start : start + page_size]

        rows = [
            {key: _sanitize(value) for key, value in record.items()}
            for record in window.to_dict(orient="records")
        ]

        return {
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": total_pages,
            "rows": rows,
        }


def get_dataset_service() -> DatasetService:
    return DatasetService.instance()
