"""Prediction history persisted to a CSV file on disk."""

from __future__ import annotations

import csv
import io
import threading
from datetime import datetime, timezone
from typing import Any

from ..config import HISTORY_FILE

FIELDS = [
    "id",
    "timestamp",
    "input_text",
    "cleaned_text",
    "predicted_category",
    "model",
    "confidence",
    "confidence_supported",
]


class HistoryStore:
    _instance: "HistoryStore | None" = None
    _lock = threading.Lock()

    def __init__(self) -> None:
        self._records: list[dict[str, Any]] = []
        self._next_id = 1
        self._io_lock = threading.Lock()

    @classmethod
    def instance(cls) -> "HistoryStore":
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    store = cls()
                    store._load()
                    cls._instance = store
        return cls._instance

    def _load(self) -> None:
        if not HISTORY_FILE.exists():
            return
        try:
            with open(HISTORY_FILE, newline="", encoding="utf-8") as handle:
                reader = csv.DictReader(handle)
                for row in reader:
                    record = self._coerce(row)
                    if record is not None:
                        self._records.append(record)
            if self._records:
                self._next_id = max(int(r["id"]) for r in self._records) + 1
        except (OSError, ValueError, KeyError):
            self._records = []

    @staticmethod
    def _coerce(row: dict[str, str]) -> dict[str, Any] | None:
        try:
            confidence_raw = row.get("confidence", "")
            confidence = float(confidence_raw) if confidence_raw not in ("", "None") else None
            return {
                "id": int(row["id"]),
                "timestamp": row["timestamp"],
                "input_text": row["input_text"],
                "cleaned_text": row.get("cleaned_text", ""),
                "predicted_category": row["predicted_category"],
                "model": row["model"],
                "confidence": confidence,
                "confidence_supported": str(
                    row.get("confidence_supported", "True")
                ).lower()
                in ("true", "1", "yes"),
            }
        except (ValueError, KeyError):
            return None

    def add(
        self,
        *,
        input_text: str,
        cleaned_text: str,
        predicted_category: str,
        model: str,
        confidence: float | None,
        confidence_supported: bool,
    ) -> dict[str, Any]:
        with self._io_lock:
            record = {
                "id": self._next_id,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "input_text": input_text,
                "cleaned_text": cleaned_text,
                "predicted_category": predicted_category,
                "model": model,
                "confidence": confidence,
                "confidence_supported": confidence_supported,
            }
            self._next_id += 1
            self._records.insert(0, record)
            self._persist()
            return record

    def _persist(self) -> None:
        HISTORY_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(HISTORY_FILE, "w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=FIELDS)
            writer.writeheader()
            for record in self._records:
                writer.writerow(
                    {
                        key: ("" if record[key] is None else record[key])
                        for key in FIELDS
                    }
                )

    def recent(self, limit: int = 8) -> list[dict[str, Any]]:
        return self._records[:limit]

    def count(self) -> int:
        return len(self._records)

    def _filtered(self, search: str | None) -> list[dict[str, Any]]:
        if not search:
            return self._records
        needle = search.strip().lower()
        return [
            record
            for record in self._records
            if needle in record["input_text"].lower()
            or needle in record["predicted_category"].lower()
            or needle in record["model"].lower()
        ]

    def query(
        self, *, search: str | None = None, page: int = 1, page_size: int = 10
    ) -> dict[str, Any]:
        records = self._filtered(search)
        total = len(records)
        page = max(1, page)
        page_size = max(1, min(page_size, 200))
        total_pages = max(1, (total + page_size - 1) // page_size)
        page = min(page, total_pages)
        start = (page - 1) * page_size
        return {
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": total_pages,
            "items": records[start : start + page_size],
        }

    def to_csv(self, search: str | None = None) -> str:
        records = self._filtered(search)
        buffer = io.StringIO()
        writer = csv.DictWriter(buffer, fieldnames=FIELDS)
        writer.writeheader()
        for record in records:
            writer.writerow(
                {key: ("" if record[key] is None else record[key]) for key in FIELDS}
            )
        return buffer.getvalue()

    def clear(self) -> int:
        with self._io_lock:
            removed = len(self._records)
            self._records = []
            self._next_id = 1
            self._persist()
            return removed


def get_history_store() -> HistoryStore:
    return HistoryStore.instance()
