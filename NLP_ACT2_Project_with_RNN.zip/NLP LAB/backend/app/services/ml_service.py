"""Loads the trained artifacts and performs real model inference."""

from __future__ import annotations

import json
import sys
import threading
from typing import Any

import joblib
import numpy as np

from ..config import ARTIFACTS_DIR, PROJECT_ROOT

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from ml.preprocessing import clean_text  # noqa: E402

MODEL_LABELS = {
    "logistic_regression": "Logistic Regression",
    "linear_svm": "Linear SVM",
    "rnn": "Recurrent Neural Network (RNN)",
}


class ArtifactsNotFoundError(RuntimeError):
    """Raised when trained artifacts are missing on disk."""


class MLService:
    """Singleton wrapper around the fitted TF-IDF vectorizer and models."""

    _instance: "MLService | None" = None
    _lock = threading.Lock()

    def __init__(self) -> None:
        self.tfidf = None
        self.models: dict[str, Any] = {}
        self.metadata: dict[str, Any] = {}
        self.classes: list[str] = []
        self._loaded = False
        self.rnn_model = None
        self.rnn_vocab: dict[str, int] = {}
        self.rnn_max_length = 100

    # -- lifecycle ---------------------------------------------------------
    @classmethod
    def instance(cls) -> "MLService":
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    service = cls()
                    service.load()
                    cls._instance = service
        return cls._instance

    def load(self) -> None:
        required = [
            ARTIFACTS_DIR / "tfidf_vectorizer.joblib",
            ARTIFACTS_DIR / "logistic_regression.joblib",
            ARTIFACTS_DIR / "linear_svm.joblib",
            ARTIFACTS_DIR / "metadata.json",
        ]
        missing = [str(path) for path in required if not path.exists()]
        if missing:
            raise ArtifactsNotFoundError(
                "Trained artifacts are missing:\n  "
                + "\n  ".join(missing)
                + "\n\nRun:  python ml/train.py"
            )

        self.tfidf = joblib.load(ARTIFACTS_DIR / "tfidf_vectorizer.joblib")
        self.models = {
            "logistic_regression": joblib.load(
                ARTIFACTS_DIR / "logistic_regression.joblib"
            ),
            "linear_svm": joblib.load(ARTIFACTS_DIR / "linear_svm.joblib"),
        }
        with open(ARTIFACTS_DIR / "metadata.json", encoding="utf-8") as handle:
            self.metadata = json.load(handle)
        self.classes = list(self.metadata["dataset"]["categories"])

        # The RNN is optional until ml/train_rnn.py has been run.
        rnn_files = [ARTIFACTS_DIR / "rnn_model.pt", ARTIFACTS_DIR / "rnn_vocab.json", ARTIFACTS_DIR / "rnn_classes.json", ARTIFACTS_DIR / "rnn_metrics.json"]
        if all(path.exists() for path in rnn_files):
            try:
                import torch
                from ml.rnn_model import TicketRNN
                checkpoint = torch.load(ARTIFACTS_DIR / "rnn_model.pt", map_location="cpu", weights_only=True)
                self.rnn_model = TicketRNN(checkpoint["vocab_size"], checkpoint["num_classes"], checkpoint["embedding_dim"], checkpoint["hidden_size"])
                self.rnn_model.load_state_dict(checkpoint["state_dict"])
                self.rnn_model.eval()
                with open(ARTIFACTS_DIR / "rnn_vocab.json", encoding="utf-8") as handle:
                    self.rnn_vocab = json.load(handle)
                with open(ARTIFACTS_DIR / "rnn_metrics.json", encoding="utf-8") as handle:
                    rnn_metrics = json.load(handle)
                self.rnn_max_length = int(rnn_metrics.get("max_length", 100))
                self.metadata.setdefault("models", {})["Recurrent Neural Network (RNN)"] = {k: rnn_metrics[k] for k in ("accuracy", "precision", "recall", "f1", "per_class", "confusion")}
                self.metadata["best_model"] = max(self.metadata["models"], key=lambda name: self.metadata["models"][name]["f1"])
            except (ImportError, RuntimeError, ValueError, KeyError, OSError) as exc:
                # Keep the classical models usable if the optional RNN artifact cannot load.
                self.rnn_model = None
        self._loaded = True

    @property
    def is_loaded(self) -> bool:
        return self._loaded

    @property
    def best_model_key(self) -> str:
        best = self.metadata.get("best_model", "Logistic Regression")
        return {"Logistic Regression": "logistic_regression", "Linear SVM": "linear_svm", "Recurrent Neural Network (RNN)": "rnn"}.get(best, "logistic_regression")

    def resolve_model_key(self, requested: str) -> str:
        if requested == "best":
            return self.best_model_key
        if requested == "rnn" and self.rnn_model is not None:
            return requested
        if requested not in self.models:
            raise KeyError(requested)
        return requested

    # -- inference ---------------------------------------------------------
    @staticmethod
    def _softmax(values: np.ndarray) -> np.ndarray:
        shifted = values - np.max(values)
        exp = np.exp(shifted)
        return exp / exp.sum()

    def predict(self, text: str, model_key: str = "best") -> dict[str, Any]:
        if not self._loaded:
            self.load()

        resolved = self.resolve_model_key(model_key)
        model = self.rnn_model if resolved == "rnn" else self.models[resolved]
        cleaned = clean_text(text)

        if not cleaned.strip():
            raise ValueError(
                "The description contains no usable text after preprocessing."
            )

        if resolved == "rnn":
            import torch
            from ml.rnn_model import encode_text
            token_ids = torch.tensor([encode_text(cleaned, self.rnn_vocab, self.rnn_max_length)], dtype=torch.long)
            with torch.no_grad():
                probabilities = torch.softmax(model(token_ids)[0], dim=0).cpu().numpy()
            categories = list(self.classes)
            predicted = categories[int(np.argmax(probabilities))]
            scores = [{"category": str(category), "score": float(score)} for category, score in zip(categories, probabilities)]
            confidence = float(np.max(probabilities))
            confidence_supported = True
            confidence_method = "softmax output of the RNN classifier"
        else:
            vector = self.tfidf.transform([cleaned])
            predicted = str(model.predict(vector)[0])

        if resolved != "rnn" and hasattr(model, "predict_proba"):
            probabilities = model.predict_proba(vector)[0]
            categories = [str(c) for c in model.classes_]
            scores = [
                {"category": category, "score": float(score)}
                for category, score in zip(categories, probabilities)
            ]
            confidence = float(max(probabilities))
            confidence_supported = True
            confidence_method = "predict_proba (calibrated probabilities)"
        elif resolved != "rnn":
            decision = model.decision_function(vector)[0]
            probabilities = self._softmax(np.asarray(decision, dtype=float))
            categories = [str(c) for c in model.classes_]
            scores = [
                {"category": category, "score": float(score)}
                for category, score in zip(categories, probabilities)
            ]
            confidence = float(max(probabilities))
            confidence_supported = True
            confidence_method = (
                "softmax of decision_function (normalized, not calibrated)"
            )

        if resolved == "rnn":
            pass
        scores.sort(key=lambda item: item["score"], reverse=True)
        return {
            "cleaned_text": cleaned,
            "predicted_category": predicted,
            "model_key": resolved,
            "model": MODEL_LABELS[resolved],
            "best_model": MODEL_LABELS[self.best_model_key],
            "is_best_model": resolved == self.best_model_key,
            "confidence": confidence,
            "confidence_supported": confidence_supported,
            "confidence_method": confidence_method,
            "scores": scores,
        }


def get_ml_service() -> MLService:
    return MLService.instance()
