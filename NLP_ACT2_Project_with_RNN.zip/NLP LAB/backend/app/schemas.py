"""Pydantic request / response schemas."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

ModelKey = Literal["best", "logistic_regression", "linear_svm", "rnn"]


class PredictRequest(BaseModel):
    text: str = Field(
        ...,
        min_length=2,
        max_length=5000,
        description="Customer support ticket description to classify.",
        examples=["I cannot use my product because it is not working."],
    )
    model: ModelKey = Field(
        "best",
        description="Which trained model to use. 'best' picks the highest F1 model.",
    )


class ScoreItem(BaseModel):
    category: str
    score: float


class PredictionResponse(BaseModel):
    input_text: str
    cleaned_text: str
    predicted_category: str
    model: str
    model_key: str
    best_model: str
    is_best_model: bool
    confidence: float | None
    confidence_supported: bool
    confidence_method: str
    scores: list[ScoreItem]
    created_at: str


class PaginatedRows(BaseModel):
    total: int
    page: int
    page_size: int
    total_pages: int
    rows: list[dict[str, Any]]


class HistoryRecord(BaseModel):
    id: int
    timestamp: str
    input_text: str
    cleaned_text: str
    predicted_category: str
    model: str
    confidence: float | None
    confidence_supported: bool


class HistoryResponse(BaseModel):
    total: int
    page: int
    page_size: int
    total_pages: int
    items: list[HistoryRecord]


class MessageResponse(BaseModel):
    message: str
