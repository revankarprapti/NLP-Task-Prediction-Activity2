"""Dashboard statistics computed from real dataset + model results."""

from __future__ import annotations

from fastapi import APIRouter

from ..services.history_store import get_history_store
from ..services.ml_service import MODEL_LABELS, get_ml_service

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.get("/stats")
def dashboard_stats() -> dict:
    ml = get_ml_service()
    history = get_history_store()

    metadata = ml.metadata
    dataset = metadata["dataset"]
    models = metadata["models"]
    best_name = metadata["best_model"]
    best_metrics = models[best_name]

    comparison = [
        {
            "model": name,
            "key": {"Logistic Regression": "logistic_regression", "Linear SVM": "linear_svm", "Recurrent Neural Network (RNN)": "rnn"}.get(name, "linear_svm"),
            "accuracy": metrics["accuracy"],
            "precision": metrics["precision"],
            "recall": metrics["recall"],
            "f1": metrics["f1"],
            "is_best": name == best_name,
        }
        for name, metrics in models.items()
    ]

    return {
        "cards": {
            "total_tickets": dataset["raw_rows"],
            "cleaned_tickets": dataset["cleaned_rows"],
            "total_categories": dataset["n_categories"],
            "accuracy": best_metrics["accuracy"],
            "precision": best_metrics["precision"],
            "recall": best_metrics["recall"],
            "f1": best_metrics["f1"],
            "total_predictions": history.count(),
        },
        "best_model": best_name,
        "best_model_key": ml.best_model_key,
        "category_distribution": dataset["class_distribution"],
        "model_comparison": comparison,
        "confusion_matrix": {
            "labels": best_metrics["confusion"]["labels"],
            "matrix": best_metrics["confusion"]["matrix"],
            "model": best_name,
        },
        "per_class": best_metrics["per_class"],
        "pipeline": {
            "train_rows": metadata["split"]["train_rows"],
            "test_rows": metadata["split"]["test_rows"],
            "vocabulary_size": metadata["features"]["vocabulary_size"],
            "ngram_range": metadata["features"]["ngram_range"],
            "max_features": metadata["features"]["max_features"],
            "test_size": metadata["split"]["test_size"],
            "random_state": metadata["split"]["random_state"],
            "generated_at": metadata["generated_at"],
        },
        "recent_predictions": [
            {
                "id": record["id"],
                "timestamp": record["timestamp"],
                "input_text": record["input_text"],
                "predicted_category": record["predicted_category"],
                "model": record["model"],
                "confidence": record["confidence"],
            }
            for record in history.recent(8)
        ],
    }
