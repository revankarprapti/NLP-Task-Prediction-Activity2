"""API routers for Automatic Task Prediction backend."""
