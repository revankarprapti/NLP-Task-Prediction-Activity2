"""Dataset explorer endpoints backed by the real CSV."""

from __future__ import annotations

from fastapi import APIRouter, Query

from ..services.dataset_service import get_dataset_service

router = APIRouter(prefix="/api/dataset", tags=["dataset"])


@router.get("")
def get_dataset(
    search: str | None = Query(None, max_length=200),
    ticket_type: str | None = Query(None),
    priority: str | None = Query(None),
    status: str | None = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=200),
) -> dict:
    service = get_dataset_service()
    result = service.query(
        search=search,
        ticket_type=ticket_type,
        priority=priority,
        status=status,
        page=page,
        page_size=page_size,
    )
    result["columns"] = service.columns
    result["stats"] = service.stats()
    result["filter_options"] = service.filter_options()
    return result
