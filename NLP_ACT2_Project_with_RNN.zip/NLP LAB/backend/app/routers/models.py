"""Model comparison endpoints - real evaluation metrics."""

from __future__ import annotations

from fastapi import APIRouter

from ..services.ml_service import MODEL_LABELS, get_ml_service

router = APIRouter(prefix="/api/models", tags=["models"])


@router.get("/comparison")
def model_comparison() -> dict:
    ml = get_ml_service()
    metadata = ml.metadata
    models = metadata["models"]
    best_name = metadata["best_model"]

    return {
        "models": [
            {
                "name": name,
                "key": {"Logistic Regression": "logistic_regression", "Linear SVM": "linear_svm", "Recurrent Neural Network (RNN)": "rnn"}.get(name, "linear_svm"),
                "accuracy": metrics["accuracy"],
                "precision": metrics["precision"],
                "recall": metrics["recall"],
                "f1": metrics["f1"],
                "is_best": name == best_name,
                "per_class": metrics["per_class"],
                "confusion": metrics["confusion"],
            }
            for name, metrics in models.items()
        ],
        "best_model": best_name,
        "best_model_key": ml.best_model_key,
        "labels": metadata["dataset"]["categories"],
        "dataset": {
            "raw_rows": metadata["dataset"]["raw_rows"],
            "cleaned_rows": metadata["dataset"]["cleaned_rows"],
            "n_categories": metadata["dataset"]["n_categories"],
            "class_distribution": metadata["dataset"]["class_distribution"],
        },
        "split": metadata["split"],
        "features": metadata["features"],
        "baseline_accuracy": round(1.0 / metadata["dataset"]["n_categories"], 4),
        "generated_at": metadata["generated_at"],
        "model_labels": MODEL_LABELS,
    }
