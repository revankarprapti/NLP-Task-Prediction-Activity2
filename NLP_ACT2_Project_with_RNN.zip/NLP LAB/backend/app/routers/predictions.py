"""Prediction history endpoints."""

from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Query
from fastapi.responses import Response

from ..schemas import HistoryResponse, MessageResponse
from ..services.history_store import get_history_store

router = APIRouter(prefix="/api/predictions", tags=["predictions"])


@router.get("/history", response_model=HistoryResponse)
def prediction_history(
    search: str | None = Query(None, max_length=200),
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=200),
) -> HistoryResponse:
    return HistoryResponse(**get_history_store().query(search=search, page=page, page_size=page_size))


@router.get("/export")
def export_predictions(search: str | None = Query(None, max_length=200)) -> Response:
    csv_content = get_history_store().to_csv(search=search)
    filename = f"prediction_history_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.csv"
    return Response(
        content=csv_content,
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.delete("/history", response_model=MessageResponse)
def clear_history() -> MessageResponse:
    removed = get_history_store().clear()
    return MessageResponse(message=f"Cleared {removed} prediction record(s).")
