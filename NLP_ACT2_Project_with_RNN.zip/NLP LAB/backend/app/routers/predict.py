"""Prediction endpoint - real ML inference, no mocks."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, status

from ..schemas import PredictRequest, PredictionResponse
from ..services.history_store import get_history_store
from ..services.ml_service import MODEL_LABELS, get_ml_service
from datetime import datetime, timezone

router = APIRouter(prefix="/api", tags=["prediction"])


@router.post("/predict", response_model=PredictionResponse)
def predict(payload: PredictRequest) -> PredictionResponse:
    ml = get_ml_service()
    text = payload.text.strip()

    if not text:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Ticket description must not be empty.",
        )

    if payload.model not in ("best", "logistic_regression", "linear_svm", "rnn"):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Unknown model '{payload.model}'.",
        )

    try:
        result = ml.predict(text, payload.model)
    except ValueError as error:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(error)
        ) from error
    except KeyError as error:  # pragma: no cover - guarded above
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Unknown model '{error.args[0]}'.",
        ) from error

    created_at = datetime.now(timezone.utc).isoformat()

    get_history_store().add(
        input_text=text,
        cleaned_text=result["cleaned_text"],
        predicted_category=result["predicted_category"],
        model=result["model"],
        confidence=result["confidence"],
        confidence_supported=result["confidence_supported"],
    )

    return PredictionResponse(
        input_text=text,
        cleaned_text=result["cleaned_text"],
        predicted_category=result["predicted_category"],
        model=result["model"],
        model_key=result["model_key"],
        best_model=result["best_model"],
        is_best_model=result["is_best_model"],
        confidence=result["confidence"],
        confidence_supported=result["confidence_supported"],
        confidence_method=result["confidence_method"],
        scores=result["scores"],
        created_at=created_at,
    )


@router.get("/predict/models")
def available_models() -> dict:
    ml = get_ml_service()
    return {
        "models": [
            {"key": key, "label": label, "is_best": key == ml.best_model_key}
            for key, label in MODEL_LABELS.items()
        ],
        "best_model_key": ml.best_model_key,
    }
