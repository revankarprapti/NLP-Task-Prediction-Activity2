# RNN Algorithm Integration Guide

## What changed
- Added a vanilla Recurrent Neural Network (RNN) classifier with an embedding layer and a multiclass output layer.
- Added `ml/train_rnn.py` to train and evaluate the RNN on the same stratified 80/20 split used by the existing Logistic Regression and Linear SVM models.
- Added `ml/rnn_model.py` for the model architecture and token-sequence encoding.
- Saved RNN weights, vocabulary, class labels, and held-out metrics in `ml/artifacts/`.
- Updated the FastAPI prediction API and frontend source so `rnn` can be selected, evaluated, and shown in the model leaderboard/charts.
- Updated API tests to include RNN prediction.

## Run it on your computer
1. Open a terminal in the `NLP LAB` project folder.
2. Install backend requirements in your virtual environment:
   `pip install -r backend/requirements.txt`
3. If you change or replace the dataset, retrain the classical models first:
   `python ml/train.py`
4. Train the RNN:
   `python ml/train_rnn.py`
5. Start the backend from the project folder using your existing project instructions. Restart it after training so the new artifacts load.
6. For the frontend, run `npm install` and then `npm run dev` inside `frontend/`.

## Current RNN result
The RNN is a working additional experimental algorithm, but its current held-out weighted F1 is about **19.27%**, below Logistic Regression on this dataset. The application therefore keeps Logistic Regression as the automatically selected model. The score is reported honestly; adding an algorithm does not guarantee that it will outperform the existing models.

## Important implementation notes
- The RNN vocabulary is learned only from training text, avoiding test-set vocabulary leakage.
- Test metrics are calculated on the held-out stratified test split.
- `backend/.env` is not included in the shared package. Use `.env.example` to create local environment settings if needed.
