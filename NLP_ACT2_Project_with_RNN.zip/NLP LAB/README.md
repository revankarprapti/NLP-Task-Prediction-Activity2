# Automatic Task Prediction Using NLP and Machine Learning

A complete, ready-to-run web application that classifies customer support tickets
into task categories using **Natural Language Processing** and **Machine Learning**.

The project is built directly from the academic notebook
(`ml/reference_notebook.ipynb`, the original `NLP-act1.ipynb`) and the real
`Customer Support Ticket Dataset.csv`. Every metric shown in the UI is computed
on the actual held-out test split — nothing is mocked or hardcoded.

---

## Real measured results

Because the dataset contains 5 roughly balanced classes, a random guess would
score **20%**. The trained models score very close to that on unseen data:

| Model                  | Accuracy | Precision | Recall | F1 Score |
|------------------------|----------|-----------|--------|----------|
| Logistic Regression    | 0.2149   | 0.2151    | 0.2149 | 0.2149   |
| Linear SVM             | 0.2107   | 0.2109    | 0.2107 | 0.2107   |

**Best model (by weighted F1): Logistic Regression** — used by default in the
prediction workspace.

> These low scores are the honest result of the data and are reported as-is:
> ticket descriptions reuse a small set of generic templates, so their wording
> is only weakly associated with the ticket type. The dashboard and model pages
> explain this limitation instead of hiding it.

---

## Tech stack

- **Frontend:** React, TypeScript, Vite, Tailwind CSS, Lucide React, Recharts, React Router
- **Backend:** Python, FastAPI, Uvicorn, Pydantic
- **ML / NLP:** Scikit-learn, Pandas, NumPy, Joblib, TF-IDF, Logistic Regression, Linear SVM

## Project structure

```
NLP LAB/
├── data/
│   └── Customer Support Ticket Dataset.csv     # raw dataset (the only real data)
├── ml/
│   ├── train.py                                # training pipeline (notebook methodology)
│   ├── preprocessing.py                        # shared clean_text used by train + API
│   ├── reference_notebook.ipynb                # the original academic notebook
│   └── artifacts/                              # joblib models + metadata (generated)
├── backend/
│   ├── app/                                    # FastAPI application
│   │   ├── config.py                           # env-driven config
│   │   ├── schemas.py                          # Pydantic models
│   │   ├── main.py                             # app entrypoint + CORS + SPA serving
│   │   ├── routers/                            # predict, dashboard, dataset, models, history
│   │   └── services/                           # ml_service, dataset_service, history_store
│   ├── tests/                                  # pytest suite
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── pages/                              # Dashboard, Predict, Dataset, Models, History
│   │   ├── components/                         # layout, charts, reusable UI
│   │   ├── lib/                                # api client, types, formatting
│   │   └── context/                            # dark/light theme
│   ├── package.json
│   └── .env.example
├── requirements.txt
├── start.ps1                                   # development launcher (2 terminals)
├── start_prod.ps1                              # production launcher (1 process)
```

`data/` contains only the raw dataset. Derived files (cleaned CSV, prediction
CSV, plots) are regenerated into `data/outputs/` by `python ml/train.py` and
are not committed.

## Machine learning methodology

Reproduced exactly from the notebook:

1. **Load** `Customer Support Ticket Dataset.csv` (8,469 rows, 17 columns).
2. **Clean column names**, count missing values and duplicate rows.
3. **Remove** exact duplicates and rows missing a description or target.
4. **NLP cleaning** (`ml/preprocessing.py`): lowercase, expand
   `{product_purchased}` → `product`, strip emails / URLs / numbers /
   punctuation, collapse whitespace.
5. **Stratified split** 80 / 20 with `random_state=42`.
6. **TF-IDF** (`stop_words="english"`, `max_features=5000`,
   `ngram_range=(1,2)`, `min_df=2`) — fitted **only** on the training split to
   prevent data leakage.
7. Train **Logistic Regression** (`max_iter=1000`) and **Linear SVM**.
8. Evaluate with accuracy / weighted precision / recall / F1 + per-class
   metrics and confusion matrices on the unseen test split.

Model, vectorizer, class names and full metadata are persisted with `joblib`
into `ml/artifacts/`.

## API reference

| Method | Endpoint                             | Description                                            |
|--------|--------------------------------------|--------------------------------------------------------|
| GET    | `/api/health`                        | Health + readiness status                              |
| GET    | `/api/dashboard/stats`               | Dashboard analytics (all real data)                    |
| GET    | `/api/dataset`                       | Paginated, filterable dataset (search/type/priority/status) |
| GET    | `/api/models/comparison`             | Both models, metrics, confusion matrices, pipeline info |
| POST   | `/api/predict`                       | Live prediction (`model`: `best` / `logistic_regression` / `linear_svm`) |
| GET    | `/api/predictions/history`           | Paginated, searchable prediction history               |
| GET    | `/api/predictions/export`            | Download prediction history as CSV                     |
| DELETE | `/api/predictions/history`           | Clear prediction history                               |

Interactive docs are available at `http://127.0.0.1:8000/docs`.

---

## Running on Windows (PowerShell)

### Prerequisites

- Python 3.11+ installed and on `PATH` (`python --version`)
- Node.js 18+ installed (`node --version`)

### 1. Install backend dependencies

```powershell
cd "C:\Users\palla\OneDrive\Desktop\NLP LAB"
python -m pip install -r requirements.txt
```

### 2. Train the models (only needed once)

```powershell
python ml\train.py
```

This reproduces the notebook results and writes the trained artifacts to
`ml\artifacts\`.

### 3. Start the backend

```powershell
cd backend
python -m uvicorn app.main:app --reload
```

The API will run at **http://127.0.0.1:8000**.

### 4. Start the frontend

In a second PowerShell window:

```powershell
cd "C:\Users\palla\OneDrive\Desktop\NLP LAB\frontend"
npm install
npm run dev
```

Open **http://localhost:5173** in your browser.

### One-click alternative

From the project root run:

```powershell
.\start.ps1
```

This starts the backend and the frontend in two separate PowerShell windows.

### Production deployment (single process)

The backend can serve the production React build on a single port — no Vite
dev server required:

```powershell
.\start_prod.ps1
```

or step by step:

```powershell
cd frontend
npm run build                       # produces frontend/dist

cd ..\backend
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 2
```

Then open **http://127.0.0.1:8000**. The React app (Dashboard, Predict,
Models, etc.) is served directly by FastAPI and talks to the API on the same
origin. `/docs` still exposes the Swagger documentation.

### Tests

```powershell
cd backend
python -m pytest -q
```

### Production build of the frontend

```powershell
cd frontend
npm run build
npm run preview   # serves the built app at http://localhost:4173
```

---

## Configuration

Copy `backend\.env.example` to `backend\.env` and `frontend\.env.example` to
`frontend\.env` to override defaults (API host/port, CORS origins, API base
URL). Defaults work out of the box.

## Notes

- Confidence for **Logistic Regression** comes from `predict_proba`
  (calibrated probabilities). For **Linear SVM**, which has no true
  probabilities, normalized softmax values of `decision_function` are shown and
  clearly labelled as uncalibrated.
- Prediction history is persisted to `data/prediction_history.csv` and survives
  backend restarts.

### Optional RNN classifier

To add the vanilla Recurrent Neural Network (RNN) to the project, install the backend requirements (including PyTorch), then run `python ml/train_rnn.py` from the `NLP LAB` project root. This trains on the same stratified 80/20 split and saves `rnn_model.pt`, `rnn_vocab.json`, `rnn_classes.json`, and `rnn_metrics.json` under `ml/artifacts/`. Restart the backend afterward. The prediction screen and model leaderboard will then include the RNN. The RNN is intentionally not selected automatically unless its measured weighted F1 is the highest.


**Important evaluation note:** The RNN is included as an additional experimental baseline. Its current held-out weighted F1 is lower than the classical models on this dataset, so the app keeps selecting the model with the highest measured weighted F1. Re-run `python ml/train_rnn.py` if you change the dataset or RNN settings, and compare all models on the same test split.
