import type {
  DashboardStats,
  DatasetResponse,
  HealthResponse,
  HistoryResponse,
  ModelComparison,
  PredictionResponse,
} from "./types";

const BASE_URL = (
  import.meta.env.VITE_API_BASE_URL ?? "http://127.0.0.1:8000"
).replace(/\/$/, "");

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

function buildQuery(params: Record<string, string | number | undefined | null>): string {
  const search = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") {
      search.set(key, String(value));
    }
  });
  const query = search.toString();
  return query ? `?${query}` : "";
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`${BASE_URL}${path}`, {
      headers: { "Content-Type": "application/json" },
      ...init,
    });
  } catch {
    throw new ApiError(
      `Cannot reach the API at ${BASE_URL}. Is the FastAPI backend running?`,
      0,
    );
  }

  if (!response.ok) {
    let detail = `Request failed with status ${response.status}`;
    try {
      const body = await response.json();
      if (body?.detail) {
        detail =
          typeof body.detail === "string"
            ? body.detail
            : JSON.stringify(body.detail);
      }
    } catch {
      /* keep default detail */
    }
    throw new ApiError(detail, response.status);
  }

  if (response.status === 204) {
    return undefined as T;
  }
  return (await response.json()) as T;
}

export const api = {
  baseUrl: BASE_URL,

  health: () => request<HealthResponse>("/api/health"),

  dashboardStats: () => request<DashboardStats>("/api/dashboard/stats"),

  modelsComparison: () => request<ModelComparison>("/api/models/comparison"),

  predict: (text: string, model: string) =>
    request<PredictionResponse>("/api/predict", {
      method: "POST",
      body: JSON.stringify({ text, model }),
    }),

  dataset: (params: {
    search?: string;
    ticket_type?: string;
    priority?: string;
    status?: string;
    page?: number;
    page_size?: number;
  }) => request<DatasetResponse>(`/api/dataset${buildQuery(params)}`),

  history: (params: { search?: string; page?: number; page_size?: number }) =>
    request<HistoryResponse>(`/api/predictions/history${buildQuery(params)}`),

  clearHistory: () =>
    request<{ message: string }>("/api/predictions/history", {
      method: "DELETE",
    }),

  exportHistoryUrl: (search?: string) =>
    `${BASE_URL}/api/predictions/export${buildQuery({ search })}`,
};
