export interface CategoryCount {
  category: string;
  count: number;
}

export interface ModelMetric {
  model: string;
  key: string;
  accuracy: number;
  precision: number;
  recall: number;
  f1: number;
  is_best: boolean;
}

export interface ConfusionMatrix {
  labels: string[];
  matrix: number[][];
  model: string;
}

export interface PerClassMetric {
  precision: number;
  recall: number;
  f1: number;
  support: number;
}

export interface RecentPrediction {
  id: number;
  timestamp: string;
  input_text: string;
  predicted_category: string;
  model: string;
  confidence: number | null;
}

export interface DashboardStats {
  cards: {
    total_tickets: number;
    cleaned_tickets: number;
    total_categories: number;
    accuracy: number;
    precision: number;
    recall: number;
    f1: number;
    total_predictions: number;
  };
  best_model: string;
  best_model_key: string;
  category_distribution: CategoryCount[];
  model_comparison: ModelMetric[];
  confusion_matrix: ConfusionMatrix;
  per_class: Record<string, PerClassMetric>;
  pipeline: {
    train_rows: number;
    test_rows: number;
    vocabulary_size: number;
    ngram_range: number[];
    max_features: number;
    test_size: number;
    random_state: number;
    generated_at: string;
  };
  recent_predictions: RecentPrediction[];
}

export interface ScoreItem {
  category: string;
  score: number;
}

export interface PredictionResponse {
  input_text: string;
  cleaned_text: string;
  predicted_category: string;
  model: string;
  model_key: string;
  best_model: string;
  is_best_model: boolean;
  confidence: number | null;
  confidence_supported: boolean;
  confidence_method: string;
  scores: ScoreItem[];
  created_at: string;
}

export interface DatasetRow {
  [key: string]: string | number | null;
}

export interface MissingValue {
  column: string;
  missing: number;
  percentage: number;
}

export interface DistributionItem {
  label: string;
  count: number;
}

export interface DatasetStats {
  total_rows: number;
  total_columns: number;
  total_categories: number;
  duplicate_rows: number;
  ticket_type_distribution: DistributionItem[];
  priority_distribution: DistributionItem[];
  status_distribution: DistributionItem[];
  channel_distribution: DistributionItem[];
  missing_values: MissingValue[];
  average_satisfaction: number | null;
  columns: string[];
}

export interface DatasetResponse {
  total: number;
  page: number;
  page_size: number;
  total_pages: number;
  rows: DatasetRow[];
  columns: string[];
  stats: DatasetStats;
  filter_options: {
    ticket_types: string[];
    priorities: string[];
    statuses: string[];
  };
}

export interface ModelComparisonModel {
  name: string;
  key: string;
  accuracy: number;
  precision: number;
  recall: number;
  f1: number;
  is_best: boolean;
  per_class: Record<string, PerClassMetric>;
  confusion: { labels: string[]; matrix: number[][] };
}

export interface ModelComparison {
  models: ModelComparisonModel[];
  best_model: string;
  best_model_key: string;
  labels: string[];
  dataset: {
    raw_rows: number;
    cleaned_rows: number;
    n_categories: number;
    class_distribution: CategoryCount[];
  };
  split: {
    test_size: number;
    random_state: number;
    stratified: boolean;
    train_rows: number;
    test_rows: number;
  };
  features: {
    vectorizer: string;
    stop_words: string;
    max_features: number;
    ngram_range: number[];
    min_df: number;
    vocabulary_size: number;
    fit_on: string;
  };
  baseline_accuracy: number;
  generated_at: string;
}

export interface HistoryRecord {
  id: number;
  timestamp: string;
  input_text: string;
  cleaned_text: string;
  predicted_category: string;
  model: string;
  confidence: number | null;
  confidence_supported: boolean;
}

export interface HistoryResponse {
  total: number;
  page: number;
  page_size: number;
  total_pages: number;
  items: HistoryRecord[];
}

export interface HealthResponse {
  status: string;
  project_root: string;
  ml_ready: boolean;
  ml_error: string | null;
}
