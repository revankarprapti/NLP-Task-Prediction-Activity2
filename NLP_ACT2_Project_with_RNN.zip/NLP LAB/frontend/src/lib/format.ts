export function formatPercent(value: number | null | undefined, digits = 1): string {
  if (value === null || value === undefined || Number.isNaN(value)) return "—";
  return `${(value * 100).toFixed(digits)}%`;
}

export function formatNumber(value: number | null | undefined): string {
  if (value === null || value === undefined || Number.isNaN(value)) return "—";
  return new Intl.NumberFormat("en-US").format(value);
}

export function formatDateTime(value: string | null | undefined): string {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString(undefined, {
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function truncate(value: string, length = 90): string {
  if (!value) return "";
  return value.length > length ? `${value.slice(0, length)}…` : value;
}

const CATEGORY_COLORS: Record<string, string> = {
  "Refund request": "#6366f1",
  "Technical issue": "#0ea5e9",
  "Cancellation request": "#f59e0b",
  "Product inquiry": "#10b981",
  "Billing inquiry": "#ef4444",
};

export function categoryColor(category: string, index = 0): string {
  if (CATEGORY_COLORS[category]) return CATEGORY_COLORS[category];
  const palette = ["#6366f1", "#0ea5e9", "#f59e0b", "#10b981", "#ef4444", "#8b5cf6"];
  return palette[index % palette.length];
}

export const MODEL_COLORS: Record<string, string> = {
  "Logistic Regression": "#6366f1",
  "Linear SVM": "#14b8a6",
  "Recurrent Neural Network (RNN)": "#8b5cf6",
  "RNN": "#8b5cf6",
};

export function metricColor(value: number): string {
  if (value >= 0.75) return "text-emerald-500";
  if (value >= 0.5) return "text-amber-500";
  return "text-rose-500";
}
