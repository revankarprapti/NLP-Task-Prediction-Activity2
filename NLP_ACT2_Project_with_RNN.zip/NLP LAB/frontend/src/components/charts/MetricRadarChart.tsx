import {
  Legend,
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  ResponsiveContainer,
  Tooltip,
} from "recharts";
import { MODEL_COLORS } from "../../lib/format";
import type { ModelComparisonModel } from "../../lib/types";
import { useChartTheme } from "./chartTheme";

export function MetricRadarChart({ models }: { models: ModelComparisonModel[] }) {
  const chart = useChartTheme();

  const modelNames: Record<string, string> = {
    logistic_regression: "Logistic Regression",
    linear_svm: "Linear SVM",
    rnn: "RNN",
  };
  const metrics = [
    { label: "Accuracy", key: "accuracy" as const },
    { label: "Precision", key: "precision" as const },
    { label: "Recall", key: "recall" as const },
    { label: "F1 Score", key: "f1" as const },
  ];
  const data = metrics.map(({ label, key }) => {
    const row: Record<string, string | number> = { metric: label };
    models.forEach((model) => { row[modelNames[model.key] ?? model.name] = model[key]; });
    return row;
  });

  return (
    <div className="h-80 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart data={data} outerRadius="72%">
          <PolarGrid stroke={chart.grid} />
          <PolarAngleAxis dataKey="metric" tick={{ fill: chart.axis, fontSize: 12 }} />
          <PolarRadiusAxis
            domain={[0, 0.3]}
            tick={{ fill: chart.axis, fontSize: 10 }}
            tickCount={4}
          />
          <Tooltip
            contentStyle={chart.tooltip}
            formatter={(value) => `${(Number(value) * 100).toFixed(2)}%`}
          />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          {models.map((model) => {
            const name = modelNames[model.key] ?? model.name;
            const color = MODEL_COLORS[name === "RNN" ? "Recurrent Neural Network (RNN)" : name] ?? "#8b5cf6";
            return (
              <Radar
                key={model.key}
                name={name}
                dataKey={name}
                stroke={color}
                fill={color}
                fillOpacity={0.22}
              />
            );
          })}
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}
