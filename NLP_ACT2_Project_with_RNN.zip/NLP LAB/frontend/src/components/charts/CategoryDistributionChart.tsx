import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { categoryColor } from "../../lib/format";
import type { CategoryCount } from "../../lib/types";
import { useChartTheme } from "./chartTheme";

export function CategoryDistributionChart({ data }: { data: CategoryCount[] }) {
  const chart = useChartTheme();
  const sorted = [...data].sort((a, b) => b.count - a.count);

  return (
    <div className="h-72 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={sorted} margin={{ top: 8, right: 8, bottom: 4, left: -16 }}>
          <CartesianGrid strokeDasharray="3 3" stroke={chart.grid} vertical={false} />
          <XAxis
            dataKey="category"
            tick={{ fill: chart.axis, fontSize: 11 }}
            tickLine={false}
            axisLine={{ stroke: chart.grid }}
            interval={0}
            tickFormatter={(value) => String(value).split(" ")[0]}
          />
          <YAxis
            tick={{ fill: chart.axis, fontSize: 11 }}
            tickLine={false}
            axisLine={false}
            width={48}
          />
          <Tooltip
            contentStyle={chart.tooltip}
            cursor={{ fill: chart.grid, opacity: 0.4 }}
            formatter={(value) => [Number(value).toLocaleString(), "Tickets"]}
          />
          <Bar dataKey="count" radius={[8, 8, 0, 0]} maxBarSize={64}>
            {sorted.map((entry, index) => (
              <Cell key={entry.category} fill={categoryColor(entry.category, index)} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
