import { useTheme } from "../../context/ThemeContext";

export function useChartTheme() {
  const { theme } = useTheme();
  const dark = theme === "dark";
  return {
    dark,
    grid: dark ? "#1e293b" : "#e2e8f0",
    axis: dark ? "#94a3b8" : "#64748b",
    tooltip: {
      backgroundColor: dark ? "#0f172a" : "#ffffff",
      border: `1px solid ${dark ? "#334155" : "#e2e8f0"}`,
      borderRadius: 12,
      fontSize: 12,
      color: dark ? "#f8fafc" : "#0f172a",
      boxShadow: "0 10px 30px -12px rgba(15,23,42,0.35)",
    },
  } as const;
}
