import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { MODEL_COLORS } from "../../lib/format";
import { useChartTheme } from "./chartTheme";

interface ComparisonDatum {
  key: string;
  model?: string;
  name?: string;
  accuracy: number;
  precision: number;
  recall: number;
  f1: number;
}

export function ModelComparisonChart({ models }: { models: ComparisonDatum[] }) {
  const chart = useChartTheme();

  const modelNames: Record<string, string> = {
    logistic_regression: "Logistic Regression",
    linear_svm: "Linear SVM",
    rnn: "RNN",
  };
  const metrics = [
    { label: "Accuracy", key: "accuracy" as const },
    { label: "Precision", key: "precision" as const },
    { label: "Recall", key: "recall" as const },
    { label: "F1 Score", key: "f1" as const },
  ];
  const data = metrics.map(({ label, key }) => {
    const row: Record<string, string | number> = { metric: label };
    models.forEach((model) => {
      row[modelNames[model.key] ?? model.name ?? model.model ?? model.key] = model[key];
    });
    return row;
  });

  return (
    <div className="h-72 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 8, bottom: 4, left: -16 }}>
          <CartesianGrid strokeDasharray="3 3" stroke={chart.grid} vertical={false} />
          <XAxis
            dataKey="metric"
            tick={{ fill: chart.axis, fontSize: 11 }}
            tickLine={false}
            axisLine={{ stroke: chart.grid }}
          />
          <YAxis
            domain={[0, 1]}
            tick={{ fill: chart.axis, fontSize: 11 }}
            tickLine={false}
            axisLine={false}
            width={48}
            tickFormatter={(value) => Number(value).toFixed(1)}
          />
          <Tooltip
            contentStyle={chart.tooltip}
            cursor={{ fill: chart.grid, opacity: 0.4 }}
            formatter={(value) => `${(Number(value) * 100).toFixed(2)}%`}
          />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          {models.map((model) => {
            const name = modelNames[model.key] ?? model.name ?? model.model ?? model.key;
            return (
              <Bar
                key={model.key}
                dataKey={name}
                fill={MODEL_COLORS[name === "RNN" ? "Recurrent Neural Network (RNN)" : name] ?? "#8b5cf6"}
                radius={[6, 6, 0, 0]}
                maxBarSize={40}
              />
            );
          })}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
