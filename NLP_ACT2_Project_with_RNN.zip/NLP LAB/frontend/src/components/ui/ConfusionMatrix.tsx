import { categoryColor } from "../../lib/format";

interface ConfusionMatrixProps {
  labels: string[];
  matrix: number[][];
  model?: string;
}

function shortLabel(label: string): string {
  return label.split(" ")[0];
}

export function ConfusionMatrix({ labels, matrix, model }: ConfusionMatrixProps) {
  const max = Math.max(1, ...matrix.flat());

  return (
    <div>
      {model ? (
        <p className="mb-3 text-xs font-medium text-slate-500 dark:text-slate-400">
          Model: <span className="text-slate-800 dark:text-slate-200">{model}</span> · darker cells
          = more tickets
        </p>
      ) : null}

      <div className="overflow-x-auto">
        <table className="w-full min-w-[520px] border-separate border-spacing-1">
          <thead>
            <tr>
              <th className="w-28 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-400">
                Actual ↓ / Pred →
              </th>
              {labels.map((label) => (
                <th
                  key={label}
                  className="px-1 pb-1 text-center text-[11px] font-semibold text-slate-500 dark:text-slate-400"
                  title={label}
                >
                  {shortLabel(label)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {matrix.map((row, rowIndex) => (
              <tr key={labels[rowIndex]}>
                <td
                  className="whitespace-nowrap pr-2 text-right text-[11px] font-semibold text-slate-500 dark:text-slate-400"
                  title={labels[rowIndex]}
                >
                  {shortLabel(labels[rowIndex])}
                </td>
                {row.map((value, colIndex) => {
                  const intensity = value / max;
                  const isDiagonal = rowIndex === colIndex;
                  const background = `rgba(99, 102, 241, ${(
                    intensity * (isDiagonal ? 0.85 : 0.6)
                  ).toFixed(3)})`;
                  const textLight = intensity > 0.45;
                  return (
                    <td key={colIndex} className="p-0">
                      <div
                        className="flex h-11 items-center justify-center rounded-lg text-xs font-semibold transition"
                        style={{
                          backgroundColor: value === 0 ? undefined : background,
                          color: textLight
                            ? "#fff"
                            : undefined,
                        }}
                        title={`Actual ${labels[rowIndex]} → Predicted ${labels[colIndex]}: ${value}`}
                      >
                        {value}
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-4 flex flex-wrap gap-x-4 gap-y-2">
        {labels.map((label, index) => (
          <span
            key={label}
            className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400"
          >
            <span
              className="h-2.5 w-2.5 rounded-full"
              style={{ backgroundColor: categoryColor(label, index) }}
            />
            {label}
          </span>
        ))}
      </div>
    </div>
  );
}
