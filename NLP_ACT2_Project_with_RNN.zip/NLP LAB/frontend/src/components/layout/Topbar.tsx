import { Menu } from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { api } from "../../lib/api";
import { ThemeToggle } from "./ThemeToggle";

const TITLES: Record<string, { title: string; subtitle: string }> = {
  "/": {
    title: "Overview Dashboard",
    subtitle: "Real-time analytics from the customer support ticket dataset",
  },
  "/predict": {
    title: "Automatic Task Prediction",
    subtitle: "Classify a support ticket into its predicted category",
  },
  "/dataset": {
    title: "Dataset Explorer",
    subtitle: "Search, filter and inspect the raw ticket dataset",
  },
  "/models": {
    title: "Model Performance",
    subtitle: "Logistic Regression, Linear SVM and RNN on unseen test data",
  },
  "/history": {
    title: "Prediction History",
    subtitle: "Every prediction recorded by the model, exportable to CSV",
  },
};

type Status = "checking" | "online" | "offline";

function ApiStatus() {
  const [status, setStatus] = useState<Status>("checking");

  useEffect(() => {
    let active = true;
    const check = async () => {
      try {
        const result = await api.health();
        if (active) setStatus(result.ml_ready ? "online" : "offline");
      } catch {
        if (active) setStatus("offline");
      }
    };
    check();
    const interval = window.setInterval(check, 15000);
    return () => {
      active = false;
      window.clearInterval(interval);
    };
  }, []);

  const config = {
    checking: { dot: "bg-amber-400", text: "Checking API…" },
    online: { dot: "bg-emerald-500", text: "API online" },
    offline: { dot: "bg-rose-500", text: "API offline" },
  }[status];

  return (
    <span className="hidden items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-600 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 sm:flex">
      <span className={`h-2 w-2 rounded-full ${config.dot} animate-pulse`} />
      {config.text}
    </span>
  );
}

export function Topbar({ onMenuClick }: { onMenuClick: () => void }) {
  const location = useLocation();
  const meta = TITLES[location.pathname] ?? {
    title: "Task Prediction",
    subtitle: "NLP & Machine Learning dashboard",
  };

  return (
    <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/80 backdrop-blur-lg dark:border-slate-800 dark:bg-slate-900/80">
      <div className="flex items-center justify-between gap-4 px-4 py-3.5 sm:px-6">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onMenuClick}
            className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-300 text-slate-600 dark:border-slate-700 dark:text-slate-300 lg:hidden"
            aria-label="Open navigation"
          >
            <Menu className="h-4 w-4" />
          </button>
          <div>
            <h1 className="text-base font-bold text-slate-900 dark:text-white sm:text-lg">
              {meta.title}
            </h1>
            <p className="hidden text-xs text-slate-500 dark:text-slate-400 sm:block">
              {meta.subtitle}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <ApiStatus />
          <ThemeToggle />
        </div>
      </div>
    </header>
  );
}
