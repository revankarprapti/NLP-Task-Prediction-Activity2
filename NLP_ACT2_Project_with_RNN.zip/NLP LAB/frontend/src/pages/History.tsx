import { Download, History as HistoryIcon, Search, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { Badge } from "../components/ui/Badge";
import { Card, CardBody, CardHeader } from "../components/ui/Card";
import { EmptyState, ErrorState } from "../components/ui/EmptyState";
import { Pagination } from "../components/ui/Pagination";
import { Spinner, Skeleton } from "../components/ui/Spinner";
import { api } from "../lib/api";
import { formatDateTime, formatPercent, truncate } from "../lib/format";
import type { HistoryResponse } from "../lib/types";
import { useApi } from "../lib/useApi";

function downloadCsv(url: string) {
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.style.display = "none";
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
}

export default function History() {
  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [clearing, setClearing] = useState(false);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      setSearch(searchInput);
      setPage(1);
    }, 350);
    return () => window.clearTimeout(timer);
  }, [searchInput]);

  const { data, loading, error, reload } = useApi<HistoryResponse>(
    () => api.history({ search, page, page_size: pageSize }),
    [search, page, pageSize],
  );

  const handleClear = async () => {
    if (!window.confirm("Delete all recorded prediction history? This cannot be undone.")) {
      return;
    }
    setClearing(true);
    try {
      await api.clearHistory();
      setPage(1);
      reload();
    } finally {
      setClearing(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader
          title="Prediction Log"
          subtitle="Every classification performed in the prediction workspace"
          icon={<HistoryIcon className="h-4.5 w-4.5" size={18} />}
          action={
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => downloadCsv(api.exportHistoryUrl(search))}
                disabled={!data || data.total === 0}
                className="btn-ghost !px-3 !py-2 text-xs"
              >
                <Download className="h-3.5 w-3.5" />
                Export CSV
              </button>
              <button
                type="button"
                onClick={handleClear}
                disabled={clearing || !data || data.total === 0}
                className="btn-ghost !px-3 !py-2 text-xs text-rose-600 hover:!bg-rose-50 dark:text-rose-300 dark:hover:!bg-rose-500/10"
              >
                {clearing ? <Spinner className="h-3.5 w-3.5" /> : <Trash2 className="h-3.5 w-3.5" />}
                Clear
              </button>
            </div>
          }
        />
        <CardBody className="border-b border-slate-200 dark:border-slate-800">
          <div className="relative max-w-md">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              value={searchInput}
              onChange={(event) => setSearchInput(event.target.value)}
              placeholder="Search text, category or model…"
              className="input pl-9"
            />
          </div>
        </CardBody>

        {error ? (
          <CardBody>
            <ErrorState message={error} onRetry={reload} />
          </CardBody>
        ) : loading ? (
          <CardBody className="space-y-2">
            {Array.from({ length: 6 }).map((_, index) => (
              <Skeleton key={index} className="h-9 w-full" />
            ))}
          </CardBody>
        ) : !data || data.items.length === 0 ? (
          <CardBody>
            <EmptyState
              title={search ? "No matching predictions" : "No predictions recorded yet"}
              description={
                search
                  ? "Try a different search term."
                  : "Predictions made in the workspace will appear here."
              }
            />
          </CardBody>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[860px] text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-left text-xs uppercase tracking-wide text-slate-400 dark:border-slate-800">
                    <th className="px-5 py-3 font-semibold">#</th>
                    <th className="px-5 py-3 font-semibold">Timestamp</th>
                    <th className="px-5 py-3 font-semibold">Ticket description</th>
                    <th className="px-5 py-3 font-semibold">Predicted category</th>
                    <th className="px-5 py-3 font-semibold">Model</th>
                    <th className="px-5 py-3 font-semibold">Confidence</th>
                  </tr>
                </thead>
                <tbody>
                  {data.items.map((item) => (
                    <tr
                      key={item.id}
                      className="border-b border-slate-100 last:border-0 hover:bg-slate-50 dark:border-slate-800/60 dark:hover:bg-slate-800/40"
                    >
                      <td className="px-5 py-3 font-mono text-xs text-slate-400">{item.id}</td>
                      <td className="whitespace-nowrap px-5 py-3 text-xs text-slate-500 dark:text-slate-400">
                        {formatDateTime(item.timestamp)}
                      </td>
                      <td className="max-w-md px-5 py-3 text-slate-600 dark:text-slate-300">
                        {truncate(item.input_text, 80)}
                      </td>
                      <td className="px-5 py-3">
                        <Badge tone="brand">{item.predicted_category}</Badge>
                      </td>
                      <td className="whitespace-nowrap px-5 py-3 text-slate-600 dark:text-slate-300">
                        {item.model}
                      </td>
                      <td className="whitespace-nowrap px-5 py-3 text-slate-600 dark:text-slate-300">
                        {item.confidence !== null
                          ? formatPercent(item.confidence, 2)
                          : "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <Pagination
              page={data.page}
              totalPages={data.total_pages}
              total={data.total}
              pageSize={data.page_size}
              onPageChange={setPage}
              onPageSizeChange={(size) => {
                setPageSize(size);
                setPage(1);
              }}
            />
          </>
        )}
      </Card>
    </div>
  );
}
