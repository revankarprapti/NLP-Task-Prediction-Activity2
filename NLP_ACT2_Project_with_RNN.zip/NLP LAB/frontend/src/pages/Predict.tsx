import {
  Bar,
  BarChart,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { CheckCircle2, FlaskConical, Sparkles, Wand2 } from "lucide-react";
import { useState } from "react";
import { useChartTheme } from "../components/charts/chartTheme";
import { Badge } from "../components/ui/Badge";
import { Card, CardBody, CardHeader } from "../components/ui/Card";
import { Spinner } from "../components/ui/Spinner";
import { api } from "../lib/api";
import { categoryColor, formatPercent } from "../lib/format";
import type { PredictionResponse } from "../lib/types";

const MODEL_OPTIONS = [
  { value: "best", label: "Best model (auto-selected)" },
  { value: "logistic_regression", label: "Logistic Regression" },
  { value: "linear_svm", label: "Linear SVM" },
  { value: "rnn", label: "Recurrent Neural Network (RNN)" },
];

const EXAMPLES = [
  "I cannot use my product because it is not working.",
  "I want to get my money back for this purchase.",
  "I would like to cancel my order.",
  "I want to know more information about this product.",
  "There is a problem with the payment on my account.",
];

function ConfidenceMeter({ value }: { value: number }) {
  const percent = Math.max(0, Math.min(1, value)) * 100;
  return (
    <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
      <div
        className="h-full rounded-full bg-gradient-to-r from-brand-500 to-violet-500 transition-all duration-700"
        style={{ width: `${percent}%` }}
      />
    </div>
  );
}

export default function Predict() {
  const chart = useChartTheme();
  const [text, setText] = useState("");
  const [model, setModel] = useState("best");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<PredictionResponse | null>(null);

  const handlePredict = async () => {
    if (text.trim().length < 2) {
      setError("Please enter at least a couple of characters describing the ticket.");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const response = await api.predict(text.trim(), model);
      setResult(response);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Prediction failed.");
      setResult(null);
    } finally {
      setLoading(false);
    }
  };

  const scoreData = result
    ? result.scores.map((item) => ({
        category: item.category,
        score: item.score,
      }))
    : [];

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
      <div className="space-y-4 lg:col-span-3">
        <Card>
          <CardHeader
            title="Ticket Description"
            subtitle="Paste a customer support ticket and classify it instantly"
            icon={<Wand2 className="h-4.5 w-4.5" size={18} />}
          />
          <CardBody className="space-y-4">
            <div>
              <label className="label" htmlFor="ticket-text">
                Description
              </label>
              <textarea
                id="ticket-text"
                value={text}
                onChange={(event) => setText(event.target.value)}
                rows={6}
                maxLength={5000}
                placeholder="e.g. I was charged twice for my subscription and need a refund."
                className="input resize-y"
              />
              <div className="mt-1 flex justify-between text-[11px] text-slate-400">
                <span>Text is cleaned with the same NLP pipeline used in training.</span>
                <span>{text.length}/5000</span>
              </div>
            </div>

            <div>
              <label className="label" htmlFor="model-select">
                Model
              </label>
              <select
                id="model-select"
                value={model}
                onChange={(event) => setModel(event.target.value)}
                className="input"
              >
                {MODEL_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <p className="label">Try an example</p>
              <div className="flex flex-wrap gap-2">
                {EXAMPLES.map((example) => (
                  <button
                    key={example}
                    type="button"
                    onClick={() => setText(example)}
                    className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs text-slate-600 transition hover:border-brand-300 hover:text-brand-700 dark:border-slate-700 dark:bg-slate-800/60 dark:text-slate-300 dark:hover:border-brand-500/40"
                  >
                    {example.length > 42 ? `${example.slice(0, 42)}…` : example}
                  </button>
                ))}
              </div>
            </div>

            {error ? (
              <p className="rounded-xl bg-rose-50 px-3.5 py-2.5 text-sm text-rose-700 dark:bg-rose-500/10 dark:text-rose-300">
                {error}
              </p>
            ) : null}

            <button
              type="button"
              onClick={handlePredict}
              disabled={loading}
              className="btn-primary w-full sm:w-auto"
            >
              {loading ? <Spinner className="h-4 w-4" /> : <Sparkles className="h-4 w-4" />}
              {loading ? "Predicting…" : "Predict Task"}
            </button>
          </CardBody>
        </Card>

        {result ? (
          <Card className="animate-fade-in">
            <CardHeader
              title="Processed Text"
              subtitle="Output of the NLP preprocessing pipeline"
              icon={<FlaskConical className="h-4.5 w-4.5" size={18} />}
            />
            <CardBody>
              <p className="rounded-xl bg-slate-50 p-3.5 font-mono text-xs leading-relaxed text-slate-600 dark:bg-slate-950 dark:text-slate-300">
                {result.cleaned_text || "(empty after cleaning)"}
              </p>
            </CardBody>
          </Card>
        ) : null}
      </div>

      <div className="space-y-4 lg:col-span-2">
        {result ? (
          <Card className="animate-fade-in">
            <CardBody className="space-y-5">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                Prediction result
              </div>

              <div className="rounded-2xl bg-gradient-to-br from-brand-600 to-violet-600 p-5 text-white shadow-lg shadow-brand-600/20">
                <p className="text-xs uppercase tracking-wide text-white/70">
                  Predicted category
                </p>
                <p className="mt-1 text-2xl font-bold">{result.predicted_category}</p>
                <div className="mt-3 flex items-center gap-2">
                  <Badge tone="slate" className="!bg-white/20 !text-white !ring-white/20">
                    {result.model}
                  </Badge>
                  {result.is_best_model ? (
                    <Badge tone="slate" className="!bg-white/20 !text-white !ring-white/20">
                      Best model
                    </Badge>
                  ) : null}
                </div>
              </div>

              <div>
                <div className="mb-1.5 flex items-center justify-between text-sm">
                  <span className="font-medium text-slate-600 dark:text-slate-300">
                    Confidence
                  </span>
                  <span className="font-semibold text-slate-900 dark:text-white">
                    {result.confidence !== null
                      ? formatPercent(result.confidence, 2)
                      : "Not available"}
                  </span>
                </div>
                {result.confidence !== null ? (
                  <ConfidenceMeter value={result.confidence} />
                ) : null}
                <p className="mt-1.5 text-[11px] text-slate-400">
                  {result.confidence_method}
                </p>
              </div>

              <div>
                <p className="label">Score per category</p>
                <div className="h-44 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={scoreData}
                      layout="vertical"
                      margin={{ top: 4, right: 16, bottom: 4, left: 8 }}
                    >
                      <XAxis type="number" domain={[0, 1]} hide />
                      <YAxis
                        type="category"
                        dataKey="category"
                        tick={{ fill: chart.axis, fontSize: 11 }}
                        tickLine={false}
                        axisLine={false}
                        width={118}
                        tickFormatter={(value) => String(value).split(" ")[0]}
                      />
                      <Tooltip
                        contentStyle={chart.tooltip}
                        cursor={{ fill: chart.grid, opacity: 0.4 }}
                        formatter={(value) => `${(Number(value) * 100).toFixed(2)}%`}
                      />
                      <Bar dataKey="score" radius={[0, 6, 6, 0]} maxBarSize={22}>
                        {scoreData.map((entry, index) => (
                          <Cell
                            key={entry.category}
                            fill={
                              entry.category === result.predicted_category
                                ? "#6366f1"
                                : categoryColor(entry.category, index)
                            }
                            fillOpacity={
                              entry.category === result.predicted_category ? 1 : 0.45
                            }
                          />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <p className="text-[11px] text-slate-400">
                Recorded to prediction history automatically.
              </p>
            </CardBody>
          </Card>
        ) : (
          <Card>
            <CardBody>
              <div className="flex flex-col items-center gap-3 py-10 text-center">
                <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-50 text-brand-600 dark:bg-brand-500/10 dark:text-brand-300">
                  <Sparkles className="h-7 w-7" />
                </span>
                <div>
                  <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                    Ready to classify
                  </p>
                  <p className="mt-1 max-w-xs text-xs text-slate-500 dark:text-slate-400">
                    Enter a ticket description and press Predict Task to see the
                    predicted category, model and confidence scores.
                  </p>
                </div>
              </div>
            </CardBody>
          </Card>
        )}
      </div>
    </div>
  );
}
