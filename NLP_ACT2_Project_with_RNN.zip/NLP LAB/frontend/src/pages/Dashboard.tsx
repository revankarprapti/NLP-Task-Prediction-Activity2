import {
  Activity,
  Award,
  Gauge,
  Layers,
  Target,
  Ticket,
  TrendingUp,
} from "lucide-react";
import { Link } from "react-router-dom";
import { CategoryDistributionChart } from "../components/charts/CategoryDistributionChart";
import { ModelComparisonChart } from "../components/charts/ModelComparisonChart";
import { Badge } from "../components/ui/Badge";
import { Card, CardBody, CardHeader } from "../components/ui/Card";
import { ConfusionMatrix } from "../components/ui/ConfusionMatrix";
import { EmptyState, ErrorState } from "../components/ui/EmptyState";
import { PageLoader } from "../components/ui/Spinner";
import { StatCard } from "../components/ui/StatCard";
import { api } from "../lib/api";
import { formatDateTime, formatNumber, formatPercent, truncate } from "../lib/format";
import type { DashboardStats } from "../lib/types";
import { useApi } from "../lib/useApi";

export default function Dashboard() {
  const { data, loading, error, reload } = useApi<DashboardStats>(() =>
    api.dashboardStats(),
  );

  if (loading) return <PageLoader label="Loading dashboard analytics…" />;
  if (error || !data) return <ErrorState message={error ?? "No data"} onRetry={reload} />;

  const { cards, pipeline } = data;
  const baseline = 1 / cards.total_categories;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Total Tickets"
          value={formatNumber(cards.total_tickets)}
          hint={`${formatNumber(cards.cleaned_tickets)} cleaned rows`}
          icon={<Ticket className="h-5 w-5" />}
          tone="brand"
        />
        <StatCard
          label="Ticket Categories"
          value={String(cards.total_categories)}
          hint="Balanced target classes"
          icon={<Layers className="h-5 w-5" />}
          tone="violet"
        />
        <StatCard
          label={`Accuracy · ${data.best_model}`}
          value={formatPercent(cards.accuracy)}
          hint={`Random baseline ${formatPercent(baseline, 0)}`}
          icon={<Target className="h-5 w-5" />}
          tone="emerald"
        />
        <StatCard
          label="Predictions Logged"
          value={formatNumber(cards.total_predictions)}
          hint="From the prediction workspace"
          icon={<Activity className="h-5 w-5" />}
          tone="sky"
        />
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard
          label="Precision (weighted)"
          value={formatPercent(cards.precision)}
          icon={<Award className="h-5 w-5" />}
          tone="brand"
        />
        <StatCard
          label="Recall (weighted)"
          value={formatPercent(cards.recall)}
          icon={<Gauge className="h-5 w-5" />}
          tone="amber"
        />
        <StatCard
          label="F1 Score (weighted)"
          value={formatPercent(cards.f1)}
          icon={<TrendingUp className="h-5 w-5" />}
          tone="rose"
        />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader
            title="Ticket Category Distribution"
            subtitle="Real counts across the five ticket types"
            icon={<Layers className="h-4.5 w-4.5" size={18} />}
          />
          <CardBody>
            <CategoryDistributionChart data={data.category_distribution} />
          </CardBody>
        </Card>

        <Card>
          <CardHeader
            title="Model Comparison"
            subtitle="Weighted metrics on unseen test data"
            icon={<TrendingUp className="h-4.5 w-4.5" size={18} />}
          />
          <CardBody>
            <ModelComparisonChart models={data.model_comparison} />
            <div className="mt-4 space-y-2">
              {data.model_comparison
                .slice()
                .sort((a, b) => b.f1 - a.f1)
                .map((model) => (
                  <div
                    key={model.key}
                    className="flex items-center justify-between rounded-xl border border-slate-200 px-3 py-2 text-sm dark:border-slate-800"
                  >
                    <span className="font-medium text-slate-700 dark:text-slate-200">
                      {model.model}
                    </span>
                    {model.is_best ? (
                      <Badge tone="emerald">Best by F1</Badge>
                    ) : (
                      <span className="text-xs text-slate-500 dark:text-slate-400">
                        F1 {formatPercent(model.f1)}
                      </span>
                    )}
                  </div>
                ))}
            </div>
          </CardBody>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader
            title="Confusion Matrix"
            subtitle={`${data.best_model} on ${formatNumber(pipeline.test_rows)} held-out tickets`}
            icon={<Target className="h-4.5 w-4.5" size={18} />}
          />
          <CardBody>
            <ConfusionMatrix
              labels={data.confusion_matrix.labels}
              matrix={data.confusion_matrix.matrix}
              model={data.confusion_matrix.model}
            />
          </CardBody>
        </Card>

        <Card>
          <CardHeader
            title="Pipeline & Limitations"
            subtitle="How the model was built"
            icon={<Gauge className="h-4.5 w-4.5" size={18} />}
          />
          <CardBody className="space-y-3 text-sm">
            <dl className="space-y-2">
              <div className="flex justify-between">
                <dt className="text-slate-500 dark:text-slate-400">Training rows</dt>
                <dd className="font-semibold">{formatNumber(pipeline.train_rows)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-500 dark:text-slate-400">Test rows</dt>
                <dd className="font-semibold">{formatNumber(pipeline.test_rows)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-500 dark:text-slate-400">Vocabulary</dt>
                <dd className="font-semibold">{formatNumber(pipeline.vocabulary_size)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-500 dark:text-slate-400">N-grams</dt>
                <dd className="font-semibold">
                  {pipeline.ngram_range[0]}–{pipeline.ngram_range[1]}
                </dd>
              </div>
            </dl>

            <div className="rounded-xl bg-amber-50 p-3 text-xs leading-relaxed text-amber-800 dark:bg-amber-500/10 dark:text-amber-200">
              <p className="font-semibold">Honest result</p>
              <p className="mt-1">
                With 5 balanced classes, guessing gives 20%. The measured accuracy of{" "}
                {formatPercent(cards.accuracy)} is only marginally above that, because ticket
                descriptions largely reuse generic templates and are weakly correlated with the
                ticket type. This limitation is reported as-is rather than inflated.
              </p>
            </div>
            <p className="text-[11px] text-slate-400">
              Trained {formatDateTime(pipeline.generated_at)}
            </p>
          </CardBody>
        </Card>
      </div>

      <Card>
        <CardHeader
          title="Recent Predictions"
          subtitle="Latest classifications from the prediction workspace"
          icon={<Activity className="h-4.5 w-4.5" size={18} />}
          action={
            <Link to="/predict" className="text-xs font-semibold text-brand-600 hover:underline dark:text-brand-300">
              New prediction
            </Link>
          }
        />
        {data.recent_predictions.length === 0 ? (
          <CardBody>
            <EmptyState
              title="No predictions yet"
              description="Open the prediction workspace and classify your first ticket."
            />
          </CardBody>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-left text-xs uppercase tracking-wide text-slate-400 dark:border-slate-800">
                  <th className="px-5 py-3 font-semibold">Ticket description</th>
                  <th className="px-5 py-3 font-semibold">Predicted category</th>
                  <th className="px-5 py-3 font-semibold">Model</th>
                  <th className="px-5 py-3 font-semibold">When</th>
                </tr>
              </thead>
              <tbody>
                {data.recent_predictions.map((row) => (
                  <tr
                    key={row.id}
                    className="border-b border-slate-100 last:border-0 hover:bg-slate-50 dark:border-slate-800/60 dark:hover:bg-slate-800/40"
                  >
                    <td className="max-w-md px-5 py-3 text-slate-600 dark:text-slate-300">
                      {truncate(row.input_text, 70)}
                    </td>
                    <td className="px-5 py-3">
                      <Badge tone="brand">{row.predicted_category}</Badge>
                    </td>
                    <td className="px-5 py-3 text-slate-600 dark:text-slate-300">
                      {row.model}
                    </td>
                    <td className="whitespace-nowrap px-5 py-3 text-xs text-slate-500 dark:text-slate-400">
                      {formatDateTime(row.timestamp)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
