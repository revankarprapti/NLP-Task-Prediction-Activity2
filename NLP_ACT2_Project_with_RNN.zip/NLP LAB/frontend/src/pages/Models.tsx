import { Award, BarChart3, Info, Layers, Target } from "lucide-react";
import { useState } from "react";
import { MetricRadarChart } from "../components/charts/MetricRadarChart";
import { ModelComparisonChart } from "../components/charts/ModelComparisonChart";
import { Badge } from "../components/ui/Badge";
import { Card, CardBody, CardHeader } from "../components/ui/Card";
import { ConfusionMatrix } from "../components/ui/ConfusionMatrix";
import { ErrorState } from "../components/ui/EmptyState";
import { PageLoader } from "../components/ui/Spinner";
import { api } from "../lib/api";
import { formatNumber, formatPercent } from "../lib/format";
import type { ModelComparison } from "../lib/types";
import { useApi } from "../lib/useApi";

export default function Models() {
  const { data, loading, error, reload } = useApi<ModelComparison>(() =>
    api.modelsComparison(),
  );
  const [activeKey, setActiveKey] = useState<string | null>(null);

  if (loading) return <PageLoader label="Loading model evaluation…" />;
  if (error || !data) return <ErrorState message={error ?? "No data"} onRetry={reload} />;

  const active = data.models.find((m) => m.key === (activeKey ?? data.best_model_key))!;
  const ranked = [...data.models].sort((a, b) => b.f1 - a.f1);

  return (
    <div className="space-y-6">
      <Card>
        <CardBody className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-300">
              <Award className="h-5 w-5" />
            </span>
            <div>
              <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Best performing model: {data.best_model}
              </p>
              <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                Selected automatically by highest weighted F1 on the unseen test split
                ({formatNumber(data.split.test_rows)} tickets).
              </p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Badge tone="slate">Baseline (random): {formatPercent(data.baseline_accuracy, 0)}</Badge>
            <Badge tone="brand">{data.features.vectorizer}</Badge>
            <Badge tone="violet">
              {data.features.ngram_range[0]}–{data.features.ngram_range[1]} n-grams
            </Badge>
          </div>
        </CardBody>
      </Card>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader
            title="Metric Comparison"
            subtitle="Accuracy, precision, recall and F1 (weighted)"
            icon={<BarChart3 className="h-4.5 w-4.5" size={18} />}
          />
          <CardBody>
            <ModelComparisonChart models={data.models} />
          </CardBody>
        </Card>

        <Card>
          <CardHeader
            title="Performance Radar"
            subtitle="Relative shape of each model's quality"
            icon={<Target className="h-4.5 w-4.5" size={18} />}
          />
          <CardBody>
            <MetricRadarChart models={data.models} />
          </CardBody>
        </Card>
      </div>

      <Card>
        <CardHeader
          title="Leaderboard"
          subtitle="Weighted evaluation metrics on held-out test data"
          icon={<Award className="h-4.5 w-4.5" size={18} />}
        />
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-xs uppercase tracking-wide text-slate-400 dark:border-slate-800">
                <th className="px-5 py-3 font-semibold">Rank</th>
                <th className="px-5 py-3 font-semibold">Model</th>
                <th className="px-5 py-3 font-semibold">Accuracy</th>
                <th className="px-5 py-3 font-semibold">Precision</th>
                <th className="px-5 py-3 font-semibold">Recall</th>
                <th className="px-5 py-3 font-semibold">F1 Score</th>
                <th className="px-5 py-3 font-semibold" />
              </tr>
            </thead>
            <tbody>
              {ranked.map((model, index) => (
                <tr
                  key={model.key}
                  className="border-b border-slate-100 last:border-0 dark:border-slate-800/60"
                >
                  <td className="px-5 py-3 font-semibold text-slate-400">#{index + 1}</td>
                  <td className="px-5 py-3 font-medium text-slate-800 dark:text-slate-200">
                    {model.name}
                  </td>
                  <td className="px-5 py-3 text-slate-600 dark:text-slate-300">
                    {formatPercent(model.accuracy, 2)}
                  </td>
                  <td className="px-5 py-3 text-slate-600 dark:text-slate-300">
                    {formatPercent(model.precision, 2)}
                  </td>
                  <td className="px-5 py-3 text-slate-600 dark:text-slate-300">
                    {formatPercent(model.recall, 2)}
                  </td>
                  <td className="px-5 py-3 font-semibold text-slate-800 dark:text-slate-100">
                    {formatPercent(model.f1, 2)}
                  </td>
                  <td className="px-5 py-3">
                    {model.is_best ? <Badge tone="emerald">Best model</Badge> : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="flex flex-wrap gap-2">
        {data.models.map((model) => (
          <button
            key={model.key}
            type="button"
            onClick={() => setActiveKey(model.key)}
            className={`rounded-xl px-4 py-2 text-sm font-semibold transition ${
              model.key === active.key
                ? "bg-brand-600 text-white"
                : "border border-slate-300 text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
            }`}
          >
            {model.name}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader
            title="Confusion Matrix"
            subtitle={`${active.name} - counts per class`}
            icon={<Target className="h-4.5 w-4.5" size={18} />}
          />
          <CardBody>
            <ConfusionMatrix
              labels={active.confusion.labels}
              matrix={active.confusion.matrix}
            />
          </CardBody>
        </Card>

        <Card>
          <CardHeader
            title="Per-Class Performance"
            subtitle={`${active.name} - precision / recall / F1 per ticket type`}
            icon={<Layers className="h-4.5 w-4.5" size={18} />}
          />
          <div className="overflow-x-auto">
            <table className="w-full min-w-[520px] text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-left text-xs uppercase tracking-wide text-slate-400 dark:border-slate-800">
                  <th className="px-5 py-3 font-semibold">Category</th>
                  <th className="px-5 py-3 font-semibold">Precision</th>
                  <th className="px-5 py-3 font-semibold">Recall</th>
                  <th className="px-5 py-3 font-semibold">F1</th>
                  <th className="px-5 py-3 font-semibold">Support</th>
                </tr>
              </thead>
              <tbody>
                {data.labels.map((label) => {
                  const metrics = active.per_class[label];
                  return (
                    <tr
                      key={label}
                      className="border-b border-slate-100 last:border-0 dark:border-slate-800/60"
                    >
                      <td className="px-5 py-3 font-medium text-slate-700 dark:text-slate-200">
                        {label}
                      </td>
                      <td className="px-5 py-3 text-slate-600 dark:text-slate-300">
                        {formatPercent(metrics?.precision ?? 0, 2)}
                      </td>
                      <td className="px-5 py-3 text-slate-600 dark:text-slate-300">
                        {formatPercent(metrics?.recall ?? 0, 2)}
                      </td>
                      <td className="px-5 py-3 font-semibold text-slate-800 dark:text-slate-100">
                        {formatPercent(metrics?.f1 ?? 0, 2)}
                      </td>
                      <td className="px-5 py-3 text-slate-500 dark:text-slate-400">
                        {formatNumber(metrics?.support ?? 0)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      </div>

      <Card>
        <CardHeader
          title="Methodology"
          subtitle="How these numbers were produced"
          icon={<Info className="h-4.5 w-4.5" size={18} />}
        />
        <CardBody className="grid grid-cols-1 gap-4 text-sm sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <p className="label">Vectorizer</p>
            <p className="text-slate-700 dark:text-slate-200">
              {data.features.vectorizer} · max {formatNumber(data.features.max_features)} features
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              {data.features.fit_on}
            </p>
          </div>
          <div>
            <p className="label">Vocabulary</p>
            <p className="text-slate-700 dark:text-slate-200">
              {formatNumber(data.features.vocabulary_size)} terms
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              min_df = {data.features.min_df}, n-grams {data.features.ngram_range.join("–")}
            </p>
          </div>
          <div>
            <p className="label">Split</p>
            <p className="text-slate-700 dark:text-slate-200">
              {formatNumber(data.split.train_rows)} train / {formatNumber(data.split.test_rows)} test
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Stratified · test_size {data.split.test_size} · seed {data.split.random_state}
            </p>
          </div>
          <div>
            <p className="label">Dataset</p>
            <p className="text-slate-700 dark:text-slate-200">
              {formatNumber(data.dataset.cleaned_rows)} rows · {data.dataset.n_categories} classes
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Evaluated on unseen test data only
            </p>
          </div>
        </CardBody>
      </Card>

      <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 dark:border-amber-500/20 dark:bg-amber-500/10 dark:text-amber-200">
        <p className="font-semibold">Why is accuracy close to {formatPercent(data.baseline_accuracy, 0)}?</p>
        <p className="mt-1 leading-relaxed">
          The ticket descriptions in this dataset reuse a small set of generic templates and their
          wording is only weakly tied to the ticket type, so a linear TF-IDF model cannot separate
          the five balanced classes much better than random guessing. The metrics above are the
          genuine measured values; they are intentionally left un-inflated to keep the project
          academically honest.
        </p>
      </div>
    </div>
  );
}
