import {
  Database,
  Filter,
  Layers,
  RotateCcw,
  Search,
  Star,
  Table2,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Badge } from "../components/ui/Badge";
import { Card, CardBody, CardHeader } from "../components/ui/Card";
import { EmptyState, ErrorState } from "../components/ui/EmptyState";
import { Pagination } from "../components/ui/Pagination";
import { Skeleton } from "../components/ui/Spinner";
import { StatCard } from "../components/ui/StatCard";
import { api } from "../lib/api";
import { formatNumber, truncate } from "../lib/format";
import type { DatasetResponse } from "../lib/types";
import { useApi } from "../lib/useApi";

const DISPLAY_COLUMNS: { key: string; label: string }[] = [
  { key: "Ticket ID", label: "ID" },
  { key: "Customer Name", label: "Customer" },
  { key: "Product Purchased", label: "Product" },
  { key: "Ticket Subject", label: "Subject" },
  { key: "Ticket Type", label: "Type" },
  { key: "Ticket Priority", label: "Priority" },
  { key: "Ticket Status", label: "Status" },
  { key: "Ticket Channel", label: "Channel" },
  { key: "Ticket Description", label: "Description" },
];

type Tone = "brand" | "emerald" | "amber" | "rose" | "sky" | "slate" | "violet";

function priorityTone(priority: string): Tone {
  switch (priority) {
    case "Critical":
      return "rose";
    case "High":
      return "amber";
    case "Medium":
      return "sky";
    default:
      return "slate";
  }
}

function statusTone(status: string): Tone {
  switch (status) {
    case "Closed":
      return "emerald";
    case "Open":
      return "sky";
    default:
      return "amber";
  }
}

function cellValue(value: string | number | null | undefined): string {
  if (value === null || value === undefined || value === "") return "—";
  return String(value);
}

export default function Dataset() {
  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");
  const [ticketType, setTicketType] = useState("");
  const [priority, setPriority] = useState("");
  const [status, setStatus] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      setSearch(searchInput);
      setPage(1);
    }, 350);
    return () => window.clearTimeout(timer);
  }, [searchInput]);

  const { data, loading, error, reload } = useApi<DatasetResponse>(
    () =>
      api.dataset({
        search,
        ticket_type: ticketType,
        priority,
        status,
        page,
        page_size: pageSize,
      }),
    [search, ticketType, priority, status, page, pageSize],
  );

  const stats = data?.stats;
  const options = data?.filter_options;

  const hasFilters = useMemo(
    () => Boolean(search || ticketType || priority || status),
    [search, ticketType, priority, status],
  );

  const resetFilters = () => {
    setSearchInput("");
    setSearch("");
    setTicketType("");
    setPriority("");
    setStatus("");
    setPage(1);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Total Rows"
          value={formatNumber(stats?.total_rows)}
          hint={`${formatNumber(stats?.total_columns)} columns`}
          icon={<Table2 className="h-5 w-5" />}
          tone="brand"
        />
        <StatCard
          label="Categories"
          value={String(stats?.total_categories ?? "—")}
          hint="Distinct ticket types"
          icon={<Layers className="h-5 w-5" />}
          tone="violet"
        />
        <StatCard
          label="Duplicate Rows"
          value={formatNumber(stats?.duplicate_rows)}
          hint="Exact duplicates detected"
          icon={<Database className="h-5 w-5" />}
          tone="sky"
        />
        <StatCard
          label="Avg. Satisfaction"
          value={
            stats?.average_satisfaction !== null && stats?.average_satisfaction !== undefined
              ? `${stats.average_satisfaction} / 5`
              : "—"
          }
          hint="Customer satisfaction rating"
          icon={<Star className="h-5 w-5" />}
          tone="amber"
        />
      </div>

      <Card>
        <CardHeader
          title="Filters"
          subtitle="Filter by ticket type, priority and status, or search text"
          icon={<Filter className="h-4.5 w-4.5" size={18} />}
          action={
            hasFilters ? (
              <button
                type="button"
                onClick={resetFilters}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-brand-600 dark:text-slate-400"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                Reset
              </button>
            ) : null
          }
        />
        <CardBody className="grid grid-cols-1 gap-3 md:grid-cols-4">
          <div className="md:col-span-2">
            <label className="label" htmlFor="dataset-search">
              Search
            </label>
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                id="dataset-search"
                value={searchInput}
                onChange={(event) => setSearchInput(event.target.value)}
                placeholder="Search description, subject or customer…"
                className="input pl-9"
              />
            </div>
          </div>

          <div>
            <label className="label" htmlFor="filter-type">
              Ticket Type
            </label>
            <select
              id="filter-type"
              value={ticketType}
              onChange={(event) => {
                setTicketType(event.target.value);
                setPage(1);
              }}
              className="input"
            >
              <option value="">All types</option>
              {options?.ticket_types.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="label" htmlFor="filter-priority">
              Priority
            </label>
            <select
              id="filter-priority"
              value={priority}
              onChange={(event) => {
                setPriority(event.target.value);
                setPage(1);
              }}
              className="input"
            >
              <option value="">All priorities</option>
              {options?.priorities.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="label" htmlFor="filter-status">
              Status
            </label>
            <select
              id="filter-status"
              value={status}
              onChange={(event) => {
                setStatus(event.target.value);
                setPage(1);
              }}
              className="input"
            >
              <option value="">All statuses</option>
              {options?.statuses.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
          </div>
        </CardBody>
      </Card>

      <Card>
        <CardHeader
          title="Ticket Records"
          subtitle={
            data ? `${formatNumber(data.total)} record(s) match the current filters` : "Loading…"
          }
          icon={<Table2 className="h-4.5 w-4.5" size={18} />}
        />

        {error ? (
          <CardBody>
            <ErrorState message={error} onRetry={reload} />
          </CardBody>
        ) : loading ? (
          <CardBody className="space-y-2">
            {Array.from({ length: 8 }).map((_, index) => (
              <Skeleton key={index} className="h-9 w-full" />
            ))}
          </CardBody>
        ) : !data || data.rows.length === 0 ? (
          <CardBody>
            <EmptyState
              title="No tickets found"
              description="Try changing or resetting the filters."
              action={
                hasFilters ? (
                  <button type="button" onClick={resetFilters} className="btn-ghost">
                    Reset filters
                  </button>
                ) : undefined
              }
            />
          </CardBody>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[960px] text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-left text-xs uppercase tracking-wide text-slate-400 dark:border-slate-800">
                    {DISPLAY_COLUMNS.map((column) => (
                      <th key={column.key} className="whitespace-nowrap px-4 py-3 font-semibold">
                        {column.label}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {data.rows.map((row, index) => (
                    <tr
                      key={`${row["Ticket ID"]}-${index}`}
                      className="border-b border-slate-100 last:border-0 hover:bg-slate-50 dark:border-slate-800/60 dark:hover:bg-slate-800/40"
                    >
                      <td className="px-4 py-3 font-mono text-xs text-slate-500 dark:text-slate-400">
                        {cellValue(row["Ticket ID"])}
                      </td>
                      <td className="whitespace-nowrap px-4 py-3 text-slate-700 dark:text-slate-200">
                        {cellValue(row["Customer Name"])}
                      </td>
                      <td className="whitespace-nowrap px-4 py-3 text-slate-600 dark:text-slate-300">
                        {cellValue(row["Product Purchased"])}
                      </td>
                      <td className="max-w-[160px] truncate px-4 py-3 text-slate-600 dark:text-slate-300">
                        {cellValue(row["Ticket Subject"])}
                      </td>
                      <td className="px-4 py-3">
                        <Badge tone="brand">{cellValue(row["Ticket Type"])}</Badge>
                      </td>
                      <td className="px-4 py-3">
                        <Badge tone={priorityTone(cellValue(row["Ticket Priority"]))}>
                          {cellValue(row["Ticket Priority"])}
                        </Badge>
                      </td>
                      <td className="px-4 py-3">
                        <Badge tone={statusTone(cellValue(row["Ticket Status"]))}>
                          {cellValue(row["Ticket Status"])}
                        </Badge>
                      </td>
                      <td className="whitespace-nowrap px-4 py-3 text-slate-600 dark:text-slate-300">
                        {cellValue(row["Ticket Channel"])}
                      </td>
                      <td className="max-w-[320px] px-4 py-3 text-slate-500 dark:text-slate-400">
                        {truncate(cellValue(row["Ticket Description"]), 80)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <Pagination
              page={data.page}
              totalPages={data.total_pages}
              total={data.total}
              pageSize={data.page_size}
              onPageChange={setPage}
              onPageSizeChange={(size) => {
                setPageSize(size);
                setPage(1);
              }}
            />
          </>
        )}
      </Card>
    </div>
  );
}
